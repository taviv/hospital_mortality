Tzvi Aviv
November 11th, 2021
Loblaw/Vector PETS workshop

This notebook will test nonFL solution for a pharmacy providing data into a hospital to predict hospital mortality in the ICU
a mockup scenario from mimic3 dataset. Data prep is in another notebook.

### Use Case

see data prep in another notebook

## **Environment Configuration and Package Imports**


```python
import os 
import warnings

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

import torch
from torch import nn
from torch.utils.data import Dataset, DataLoader
from torch.utils.data._utils.collate import default_collate

from sklearn.metrics import roc_auc_score

import syft as sy
#from uuid import UUID
#from uuid import uuid4

hook = sy.TorchHook(torch) 
```

    Using TensorFlow backend.



```python
#from src.psi.util import Client, Server
#from src.utils import add_ids
#from src.utils.data_utils import id_collate_fn
```


```python
from sklearn.preprocessing import MinMaxScaler
```


```python
import matplotlib.pyplot as plt

from sklearn.metrics import confusion_matrix
#from resources.plotcm import plot_confusion_matrix
```

### Define Dataset Class

### Load Data



```python
!pwd
```

    /ssd003/home/taviv/mimic3-benchmarks/VFL_PySyft_SplitNN



```python
!ls ..
```

    data				   mimic3benchmark     test_data.npy
    data_ta				   mimic3models        test_lbl.npy
    feature_table.csv		   pharmacy_test.csv   train_data.npy
    Hospital_mortality_episodes.ipynb  pharmacy_train.csv  train_lbl.npy
    hospital_test.csv		   README.md	       val_data.npy
    hospital_train.csv		   requirements.txt    val_lbl.npy
    LICENSE				   statistics.md       VFL_PySyft_SplitNN



```python
# Load pharmacy
data_dir = "/ssd003/home/taviv/mimic3-benchmarks"
PH_DATA_PATH = f"{data_dir}/pharmacy_train.csv"
ph_df = pd.read_csv(PH_DATA_PATH)
ph_df.rename(columns={"Unnamed: 0":"SUBJ_ID"}, inplace=True)
```


```python
#fill nan with zeros
#ph_df = ph_df.fillna(0)
```


```python
#scaling
#ph_df=pd.DataFrame(MinMaxScaler().fit_transform(ph_df))
```


```python
ph_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>SUBJ_ID</th>
      <th>42</th>
      <th>43</th>
      <th>44</th>
      <th>45</th>
      <th>46</th>
      <th>47</th>
      <th>48</th>
      <th>49</th>
      <th>50</th>
      <th>...</th>
      <th>663</th>
      <th>664</th>
      <th>665</th>
      <th>666</th>
      <th>667</th>
      <th>668</th>
      <th>669</th>
      <th>670</th>
      <th>671</th>
      <th>label</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>97271</td>
      <td>39.0</td>
      <td>69.0</td>
      <td>52.246376</td>
      <td>6.477175</td>
      <td>0.542092</td>
      <td>69.0</td>
      <td>39.0</td>
      <td>53.0</td>
      <td>48.444443</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>114.000000</td>
      <td>114.000000</td>
      <td>114.000000</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>29742</td>
      <td>41.0</td>
      <td>120.0</td>
      <td>63.802818</td>
      <td>13.510162</td>
      <td>1.704696</td>
      <td>71.0</td>
      <td>53.0</td>
      <td>99.0</td>
      <td>68.400002</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3362</td>
      <td>36.0</td>
      <td>68.0</td>
      <td>48.981480</td>
      <td>7.778152</td>
      <td>0.697511</td>
      <td>54.0</td>
      <td>54.0</td>
      <td>68.0</td>
      <td>63.000000</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>118.599998</td>
      <td>118.599998</td>
      <td>118.599998</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>5407</td>
      <td>37.0</td>
      <td>82.0</td>
      <td>51.491802</td>
      <td>7.723974</td>
      <td>0.973102</td>
      <td>61.0</td>
      <td>42.0</td>
      <td>58.0</td>
      <td>49.500000</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>90.400002</td>
      <td>90.400002</td>
      <td>90.400002</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>19220</td>
      <td>37.0</td>
      <td>89.0</td>
      <td>57.854168</td>
      <td>9.302754</td>
      <td>0.307232</td>
      <td>48.0</td>
      <td>37.0</td>
      <td>62.0</td>
      <td>50.200001</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 212 columns</p>
</div>




```python
ph_df.label.value_counts()
```




    0    9998
    1    1567
    Name: label, dtype: int64




```python
#Load Hospital Data
HO_DATA_PATH = f"{data_dir}/hospital_train.csv"
ho_df = pd.read_csv(HO_DATA_PATH)
ho_df.rename(columns={"Unnamed: 0":"SUBJ_ID"}, inplace=True)
```


```python
from pycaret.classification import *
```


```python
exp_ho = setup(ho_df.iloc[:,1:], target = 'label')
```


<style type="text/css">
#T_472db_row5_col1, #T_472db_row44_col1 {
  background-color: lightgreen;
}
</style>
<table id="T_472db_">
  <thead>
    <tr>
      <th class="blank level0" >&nbsp;</th>
      <th class="col_heading level0 col0" >Description</th>
      <th class="col_heading level0 col1" >Value</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th id="T_472db_level0_row0" class="row_heading level0 row0" >0</th>
      <td id="T_472db_row0_col0" class="data row0 col0" >session_id</td>
      <td id="T_472db_row0_col1" class="data row0 col1" >5898</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row1" class="row_heading level0 row1" >1</th>
      <td id="T_472db_row1_col0" class="data row1 col0" >Target</td>
      <td id="T_472db_row1_col1" class="data row1 col1" >label</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row2" class="row_heading level0 row2" >2</th>
      <td id="T_472db_row2_col0" class="data row2 col0" >Target Type</td>
      <td id="T_472db_row2_col1" class="data row2 col1" >Binary</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row3" class="row_heading level0 row3" >3</th>
      <td id="T_472db_row3_col0" class="data row3 col0" >Label Encoded</td>
      <td id="T_472db_row3_col1" class="data row3 col1" >None</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row4" class="row_heading level0 row4" >4</th>
      <td id="T_472db_row4_col0" class="data row4 col0" >Original Data</td>
      <td id="T_472db_row4_col1" class="data row4 col1" >(11565, 421)</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row5" class="row_heading level0 row5" >5</th>
      <td id="T_472db_row5_col0" class="data row5 col0" >Missing Values</td>
      <td id="T_472db_row5_col1" class="data row5 col1" >True</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row6" class="row_heading level0 row6" >6</th>
      <td id="T_472db_row6_col0" class="data row6 col0" >Numeric Features</td>
      <td id="T_472db_row6_col1" class="data row6 col1" >344</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row7" class="row_heading level0 row7" >7</th>
      <td id="T_472db_row7_col0" class="data row7 col0" >Categorical Features</td>
      <td id="T_472db_row7_col1" class="data row7 col1" >76</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row8" class="row_heading level0 row8" >8</th>
      <td id="T_472db_row8_col0" class="data row8 col0" >Ordinal Features</td>
      <td id="T_472db_row8_col1" class="data row8 col1" >False</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row9" class="row_heading level0 row9" >9</th>
      <td id="T_472db_row9_col0" class="data row9 col0" >High Cardinality Features</td>
      <td id="T_472db_row9_col1" class="data row9 col1" >False</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row10" class="row_heading level0 row10" >10</th>
      <td id="T_472db_row10_col0" class="data row10 col0" >High Cardinality Method</td>
      <td id="T_472db_row10_col1" class="data row10 col1" >None</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row11" class="row_heading level0 row11" >11</th>
      <td id="T_472db_row11_col0" class="data row11 col0" >Transformed Train Set</td>
      <td id="T_472db_row11_col1" class="data row11 col1" >(8095, 935)</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row12" class="row_heading level0 row12" >12</th>
      <td id="T_472db_row12_col0" class="data row12 col0" >Transformed Test Set</td>
      <td id="T_472db_row12_col1" class="data row12 col1" >(3470, 935)</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row13" class="row_heading level0 row13" >13</th>
      <td id="T_472db_row13_col0" class="data row13 col0" >Shuffle Train-Test</td>
      <td id="T_472db_row13_col1" class="data row13 col1" >True</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row14" class="row_heading level0 row14" >14</th>
      <td id="T_472db_row14_col0" class="data row14 col0" >Stratify Train-Test</td>
      <td id="T_472db_row14_col1" class="data row14 col1" >False</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row15" class="row_heading level0 row15" >15</th>
      <td id="T_472db_row15_col0" class="data row15 col0" >Fold Generator</td>
      <td id="T_472db_row15_col1" class="data row15 col1" >StratifiedKFold</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row16" class="row_heading level0 row16" >16</th>
      <td id="T_472db_row16_col0" class="data row16 col0" >Fold Number</td>
      <td id="T_472db_row16_col1" class="data row16 col1" >10</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row17" class="row_heading level0 row17" >17</th>
      <td id="T_472db_row17_col0" class="data row17 col0" >CPU Jobs</td>
      <td id="T_472db_row17_col1" class="data row17 col1" >-1</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row18" class="row_heading level0 row18" >18</th>
      <td id="T_472db_row18_col0" class="data row18 col0" >Use GPU</td>
      <td id="T_472db_row18_col1" class="data row18 col1" >False</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row19" class="row_heading level0 row19" >19</th>
      <td id="T_472db_row19_col0" class="data row19 col0" >Log Experiment</td>
      <td id="T_472db_row19_col1" class="data row19 col1" >False</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row20" class="row_heading level0 row20" >20</th>
      <td id="T_472db_row20_col0" class="data row20 col0" >Experiment Name</td>
      <td id="T_472db_row20_col1" class="data row20 col1" >clf-default-name</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row21" class="row_heading level0 row21" >21</th>
      <td id="T_472db_row21_col0" class="data row21 col0" >USI</td>
      <td id="T_472db_row21_col1" class="data row21 col1" >201a</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row22" class="row_heading level0 row22" >22</th>
      <td id="T_472db_row22_col0" class="data row22 col0" >Imputation Type</td>
      <td id="T_472db_row22_col1" class="data row22 col1" >simple</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row23" class="row_heading level0 row23" >23</th>
      <td id="T_472db_row23_col0" class="data row23 col0" >Iterative Imputation Iteration</td>
      <td id="T_472db_row23_col1" class="data row23 col1" >None</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row24" class="row_heading level0 row24" >24</th>
      <td id="T_472db_row24_col0" class="data row24 col0" >Numeric Imputer</td>
      <td id="T_472db_row24_col1" class="data row24 col1" >mean</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row25" class="row_heading level0 row25" >25</th>
      <td id="T_472db_row25_col0" class="data row25 col0" >Iterative Imputation Numeric Model</td>
      <td id="T_472db_row25_col1" class="data row25 col1" >None</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row26" class="row_heading level0 row26" >26</th>
      <td id="T_472db_row26_col0" class="data row26 col0" >Categorical Imputer</td>
      <td id="T_472db_row26_col1" class="data row26 col1" >constant</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row27" class="row_heading level0 row27" >27</th>
      <td id="T_472db_row27_col0" class="data row27 col0" >Iterative Imputation Categorical Model</td>
      <td id="T_472db_row27_col1" class="data row27 col1" >None</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row28" class="row_heading level0 row28" >28</th>
      <td id="T_472db_row28_col0" class="data row28 col0" >Unknown Categoricals Handling</td>
      <td id="T_472db_row28_col1" class="data row28 col1" >least_frequent</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row29" class="row_heading level0 row29" >29</th>
      <td id="T_472db_row29_col0" class="data row29 col0" >Normalize</td>
      <td id="T_472db_row29_col1" class="data row29 col1" >False</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row30" class="row_heading level0 row30" >30</th>
      <td id="T_472db_row30_col0" class="data row30 col0" >Normalize Method</td>
      <td id="T_472db_row30_col1" class="data row30 col1" >None</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row31" class="row_heading level0 row31" >31</th>
      <td id="T_472db_row31_col0" class="data row31 col0" >Transformation</td>
      <td id="T_472db_row31_col1" class="data row31 col1" >False</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row32" class="row_heading level0 row32" >32</th>
      <td id="T_472db_row32_col0" class="data row32 col0" >Transformation Method</td>
      <td id="T_472db_row32_col1" class="data row32 col1" >None</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row33" class="row_heading level0 row33" >33</th>
      <td id="T_472db_row33_col0" class="data row33 col0" >PCA</td>
      <td id="T_472db_row33_col1" class="data row33 col1" >False</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row34" class="row_heading level0 row34" >34</th>
      <td id="T_472db_row34_col0" class="data row34 col0" >PCA Method</td>
      <td id="T_472db_row34_col1" class="data row34 col1" >None</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row35" class="row_heading level0 row35" >35</th>
      <td id="T_472db_row35_col0" class="data row35 col0" >PCA Components</td>
      <td id="T_472db_row35_col1" class="data row35 col1" >None</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row36" class="row_heading level0 row36" >36</th>
      <td id="T_472db_row36_col0" class="data row36 col0" >Ignore Low Variance</td>
      <td id="T_472db_row36_col1" class="data row36 col1" >False</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row37" class="row_heading level0 row37" >37</th>
      <td id="T_472db_row37_col0" class="data row37 col0" >Combine Rare Levels</td>
      <td id="T_472db_row37_col1" class="data row37 col1" >False</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row38" class="row_heading level0 row38" >38</th>
      <td id="T_472db_row38_col0" class="data row38 col0" >Rare Level Threshold</td>
      <td id="T_472db_row38_col1" class="data row38 col1" >None</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row39" class="row_heading level0 row39" >39</th>
      <td id="T_472db_row39_col0" class="data row39 col0" >Numeric Binning</td>
      <td id="T_472db_row39_col1" class="data row39 col1" >False</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row40" class="row_heading level0 row40" >40</th>
      <td id="T_472db_row40_col0" class="data row40 col0" >Remove Outliers</td>
      <td id="T_472db_row40_col1" class="data row40 col1" >False</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row41" class="row_heading level0 row41" >41</th>
      <td id="T_472db_row41_col0" class="data row41 col0" >Outliers Threshold</td>
      <td id="T_472db_row41_col1" class="data row41 col1" >None</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row42" class="row_heading level0 row42" >42</th>
      <td id="T_472db_row42_col0" class="data row42 col0" >Remove Multicollinearity</td>
      <td id="T_472db_row42_col1" class="data row42 col1" >False</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row43" class="row_heading level0 row43" >43</th>
      <td id="T_472db_row43_col0" class="data row43 col0" >Multicollinearity Threshold</td>
      <td id="T_472db_row43_col1" class="data row43 col1" >None</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row44" class="row_heading level0 row44" >44</th>
      <td id="T_472db_row44_col0" class="data row44 col0" >Remove Perfect Collinearity</td>
      <td id="T_472db_row44_col1" class="data row44 col1" >True</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row45" class="row_heading level0 row45" >45</th>
      <td id="T_472db_row45_col0" class="data row45 col0" >Clustering</td>
      <td id="T_472db_row45_col1" class="data row45 col1" >False</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row46" class="row_heading level0 row46" >46</th>
      <td id="T_472db_row46_col0" class="data row46 col0" >Clustering Iteration</td>
      <td id="T_472db_row46_col1" class="data row46 col1" >None</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row47" class="row_heading level0 row47" >47</th>
      <td id="T_472db_row47_col0" class="data row47 col0" >Polynomial Features</td>
      <td id="T_472db_row47_col1" class="data row47 col1" >False</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row48" class="row_heading level0 row48" >48</th>
      <td id="T_472db_row48_col0" class="data row48 col0" >Polynomial Degree</td>
      <td id="T_472db_row48_col1" class="data row48 col1" >None</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row49" class="row_heading level0 row49" >49</th>
      <td id="T_472db_row49_col0" class="data row49 col0" >Trignometry Features</td>
      <td id="T_472db_row49_col1" class="data row49 col1" >False</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row50" class="row_heading level0 row50" >50</th>
      <td id="T_472db_row50_col0" class="data row50 col0" >Polynomial Threshold</td>
      <td id="T_472db_row50_col1" class="data row50 col1" >None</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row51" class="row_heading level0 row51" >51</th>
      <td id="T_472db_row51_col0" class="data row51 col0" >Group Features</td>
      <td id="T_472db_row51_col1" class="data row51 col1" >False</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row52" class="row_heading level0 row52" >52</th>
      <td id="T_472db_row52_col0" class="data row52 col0" >Feature Selection</td>
      <td id="T_472db_row52_col1" class="data row52 col1" >False</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row53" class="row_heading level0 row53" >53</th>
      <td id="T_472db_row53_col0" class="data row53 col0" >Feature Selection Method</td>
      <td id="T_472db_row53_col1" class="data row53 col1" >classic</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row54" class="row_heading level0 row54" >54</th>
      <td id="T_472db_row54_col0" class="data row54 col0" >Features Selection Threshold</td>
      <td id="T_472db_row54_col1" class="data row54 col1" >None</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row55" class="row_heading level0 row55" >55</th>
      <td id="T_472db_row55_col0" class="data row55 col0" >Feature Interaction</td>
      <td id="T_472db_row55_col1" class="data row55 col1" >False</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row56" class="row_heading level0 row56" >56</th>
      <td id="T_472db_row56_col0" class="data row56 col0" >Feature Ratio</td>
      <td id="T_472db_row56_col1" class="data row56 col1" >False</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row57" class="row_heading level0 row57" >57</th>
      <td id="T_472db_row57_col0" class="data row57 col0" >Interaction Threshold</td>
      <td id="T_472db_row57_col1" class="data row57 col1" >None</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row58" class="row_heading level0 row58" >58</th>
      <td id="T_472db_row58_col0" class="data row58 col0" >Fix Imbalance</td>
      <td id="T_472db_row58_col1" class="data row58 col1" >False</td>
    </tr>
    <tr>
      <th id="T_472db_level0_row59" class="row_heading level0 row59" >59</th>
      <td id="T_472db_row59_col0" class="data row59 col0" >Fix Imbalance Method</td>
      <td id="T_472db_row59_col1" class="data row59 col1" >SMOTE</td>
    </tr>
  </tbody>
</table>




```python
compare_models()
```


<style type="text/css">
#T_b77b4_ th {
  text-align: left;
}
#T_b77b4_row0_col0, #T_b77b4_row0_col2, #T_b77b4_row0_col3, #T_b77b4_row0_col4, #T_b77b4_row0_col5, #T_b77b4_row0_col6, #T_b77b4_row1_col0, #T_b77b4_row1_col1, #T_b77b4_row1_col3, #T_b77b4_row1_col4, #T_b77b4_row1_col5, #T_b77b4_row1_col7, #T_b77b4_row2_col0, #T_b77b4_row2_col1, #T_b77b4_row2_col2, #T_b77b4_row2_col3, #T_b77b4_row2_col5, #T_b77b4_row2_col6, #T_b77b4_row2_col7, #T_b77b4_row3_col0, #T_b77b4_row3_col1, #T_b77b4_row3_col2, #T_b77b4_row3_col3, #T_b77b4_row3_col4, #T_b77b4_row3_col5, #T_b77b4_row3_col6, #T_b77b4_row3_col7, #T_b77b4_row4_col0, #T_b77b4_row4_col1, #T_b77b4_row4_col2, #T_b77b4_row4_col3, #T_b77b4_row4_col4, #T_b77b4_row4_col5, #T_b77b4_row4_col6, #T_b77b4_row4_col7, #T_b77b4_row5_col0, #T_b77b4_row5_col1, #T_b77b4_row5_col2, #T_b77b4_row5_col3, #T_b77b4_row5_col4, #T_b77b4_row5_col5, #T_b77b4_row5_col6, #T_b77b4_row5_col7, #T_b77b4_row6_col0, #T_b77b4_row6_col1, #T_b77b4_row6_col2, #T_b77b4_row6_col3, #T_b77b4_row6_col4, #T_b77b4_row6_col5, #T_b77b4_row6_col6, #T_b77b4_row6_col7, #T_b77b4_row7_col0, #T_b77b4_row7_col1, #T_b77b4_row7_col2, #T_b77b4_row7_col3, #T_b77b4_row7_col4, #T_b77b4_row7_col6, #T_b77b4_row7_col7, #T_b77b4_row8_col0, #T_b77b4_row8_col1, #T_b77b4_row8_col2, #T_b77b4_row8_col3, #T_b77b4_row8_col4, #T_b77b4_row8_col5, #T_b77b4_row8_col6, #T_b77b4_row8_col7, #T_b77b4_row9_col0, #T_b77b4_row9_col1, #T_b77b4_row9_col2, #T_b77b4_row9_col3, #T_b77b4_row9_col4, #T_b77b4_row9_col5, #T_b77b4_row9_col6, #T_b77b4_row9_col7, #T_b77b4_row10_col0, #T_b77b4_row10_col1, #T_b77b4_row10_col2, #T_b77b4_row10_col3, #T_b77b4_row10_col4, #T_b77b4_row10_col5, #T_b77b4_row10_col6, #T_b77b4_row10_col7, #T_b77b4_row11_col0, #T_b77b4_row11_col1, #T_b77b4_row11_col2, #T_b77b4_row11_col3, #T_b77b4_row11_col4, #T_b77b4_row11_col5, #T_b77b4_row11_col6, #T_b77b4_row11_col7, #T_b77b4_row12_col0, #T_b77b4_row12_col1, #T_b77b4_row12_col2, #T_b77b4_row12_col4, #T_b77b4_row12_col5, #T_b77b4_row12_col6, #T_b77b4_row12_col7 {
  text-align: left;
}
#T_b77b4_row0_col1, #T_b77b4_row0_col7, #T_b77b4_row1_col2, #T_b77b4_row1_col6, #T_b77b4_row2_col4, #T_b77b4_row7_col5, #T_b77b4_row12_col3 {
  text-align: left;
  background-color: yellow;
}
#T_b77b4_row0_col8, #T_b77b4_row1_col8, #T_b77b4_row2_col8, #T_b77b4_row3_col8, #T_b77b4_row4_col8, #T_b77b4_row5_col8, #T_b77b4_row6_col8, #T_b77b4_row7_col8, #T_b77b4_row8_col8, #T_b77b4_row9_col8, #T_b77b4_row10_col8, #T_b77b4_row12_col8 {
  text-align: left;
  background-color: lightgrey;
}
#T_b77b4_row11_col8 {
  text-align: left;
  background-color: yellow;
  background-color: lightgrey;
}
</style>
<table id="T_b77b4_">
  <thead>
    <tr>
      <th class="blank level0" >&nbsp;</th>
      <th class="col_heading level0 col0" >Model</th>
      <th class="col_heading level0 col1" >Accuracy</th>
      <th class="col_heading level0 col2" >AUC</th>
      <th class="col_heading level0 col3" >Recall</th>
      <th class="col_heading level0 col4" >Prec.</th>
      <th class="col_heading level0 col5" >F1</th>
      <th class="col_heading level0 col6" >Kappa</th>
      <th class="col_heading level0 col7" >MCC</th>
      <th class="col_heading level0 col8" >TT (Sec)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th id="T_b77b4_level0_row0" class="row_heading level0 row0" >gbc</th>
      <td id="T_b77b4_row0_col0" class="data row0 col0" >Gradient Boosting Classifier</td>
      <td id="T_b77b4_row0_col1" class="data row0 col1" >0.8851</td>
      <td id="T_b77b4_row0_col2" class="data row0 col2" >0.8577</td>
      <td id="T_b77b4_row0_col3" class="data row0 col3" >0.3000</td>
      <td id="T_b77b4_row0_col4" class="data row0 col4" >0.6602</td>
      <td id="T_b77b4_row0_col5" class="data row0 col5" >0.4114</td>
      <td id="T_b77b4_row0_col6" class="data row0 col6" >0.3579</td>
      <td id="T_b77b4_row0_col7" class="data row0 col7" >0.3927</td>
      <td id="T_b77b4_row0_col8" class="data row0 col8" >17.6120</td>
    </tr>
    <tr>
      <th id="T_b77b4_level0_row1" class="row_heading level0 row1" >lightgbm</th>
      <td id="T_b77b4_row1_col0" class="data row1 col0" >Light Gradient Boosting Machine</td>
      <td id="T_b77b4_row1_col1" class="data row1 col1" >0.8847</td>
      <td id="T_b77b4_row1_col2" class="data row1 col2" >0.8581</td>
      <td id="T_b77b4_row1_col3" class="data row1 col3" >0.3018</td>
      <td id="T_b77b4_row1_col4" class="data row1 col4" >0.6570</td>
      <td id="T_b77b4_row1_col5" class="data row1 col5" >0.4128</td>
      <td id="T_b77b4_row1_col6" class="data row1 col6" >0.3587</td>
      <td id="T_b77b4_row1_col7" class="data row1 col7" >0.3925</td>
      <td id="T_b77b4_row1_col8" class="data row1 col8" >2.1440</td>
    </tr>
    <tr>
      <th id="T_b77b4_level0_row2" class="row_heading level0 row2" >rf</th>
      <td id="T_b77b4_row2_col0" class="data row2 col0" >Random Forest Classifier</td>
      <td id="T_b77b4_row2_col1" class="data row2 col1" >0.8824</td>
      <td id="T_b77b4_row2_col2" class="data row2 col2" >0.8449</td>
      <td id="T_b77b4_row2_col3" class="data row2 col3" >0.2239</td>
      <td id="T_b77b4_row2_col4" class="data row2 col4" >0.6967</td>
      <td id="T_b77b4_row2_col5" class="data row2 col5" >0.3370</td>
      <td id="T_b77b4_row2_col6" class="data row2 col6" >0.2912</td>
      <td id="T_b77b4_row2_col7" class="data row2 col7" >0.3491</td>
      <td id="T_b77b4_row2_col8" class="data row2 col8" >2.4010</td>
    </tr>
    <tr>
      <th id="T_b77b4_level0_row3" class="row_heading level0 row3" >et</th>
      <td id="T_b77b4_row3_col0" class="data row3 col0" >Extra Trees Classifier</td>
      <td id="T_b77b4_row3_col1" class="data row3 col1" >0.8817</td>
      <td id="T_b77b4_row3_col2" class="data row3 col2" >0.8368</td>
      <td id="T_b77b4_row3_col3" class="data row3 col3" >0.2284</td>
      <td id="T_b77b4_row3_col4" class="data row3 col4" >0.6776</td>
      <td id="T_b77b4_row3_col5" class="data row3 col5" >0.3396</td>
      <td id="T_b77b4_row3_col6" class="data row3 col6" >0.2924</td>
      <td id="T_b77b4_row3_col7" class="data row3 col7" >0.3458</td>
      <td id="T_b77b4_row3_col8" class="data row3 col8" >1.5780</td>
    </tr>
    <tr>
      <th id="T_b77b4_level0_row4" class="row_heading level0 row4" >ridge</th>
      <td id="T_b77b4_row4_col0" class="data row4 col0" >Ridge Classifier</td>
      <td id="T_b77b4_row4_col1" class="data row4 col1" >0.8752</td>
      <td id="T_b77b4_row4_col2" class="data row4 col2" >0.0000</td>
      <td id="T_b77b4_row4_col3" class="data row4 col3" >0.2789</td>
      <td id="T_b77b4_row4_col4" class="data row4 col4" >0.5766</td>
      <td id="T_b77b4_row4_col5" class="data row4 col5" >0.3745</td>
      <td id="T_b77b4_row4_col6" class="data row4 col6" >0.3147</td>
      <td id="T_b77b4_row4_col7" class="data row4 col7" >0.3410</td>
      <td id="T_b77b4_row4_col8" class="data row4 col8" >0.1700</td>
    </tr>
    <tr>
      <th id="T_b77b4_level0_row5" class="row_heading level0 row5" >ada</th>
      <td id="T_b77b4_row5_col0" class="data row5 col0" >Ada Boost Classifier</td>
      <td id="T_b77b4_row5_col1" class="data row5 col1" >0.8721</td>
      <td id="T_b77b4_row5_col2" class="data row5 col2" >0.8401</td>
      <td id="T_b77b4_row5_col3" class="data row5 col3" >0.3266</td>
      <td id="T_b77b4_row5_col4" class="data row5 col4" >0.5415</td>
      <td id="T_b77b4_row5_col5" class="data row5 col5" >0.4063</td>
      <td id="T_b77b4_row5_col6" class="data row5 col6" >0.3398</td>
      <td id="T_b77b4_row5_col7" class="data row5 col7" >0.3540</td>
      <td id="T_b77b4_row5_col8" class="data row5 col8" >3.4610</td>
    </tr>
    <tr>
      <th id="T_b77b4_level0_row6" class="row_heading level0 row6" >lr</th>
      <td id="T_b77b4_row6_col0" class="data row6 col0" >Logistic Regression</td>
      <td id="T_b77b4_row6_col1" class="data row6 col1" >0.8713</td>
      <td id="T_b77b4_row6_col2" class="data row6 col2" >0.8223</td>
      <td id="T_b77b4_row6_col3" class="data row6 col3" >0.2954</td>
      <td id="T_b77b4_row6_col4" class="data row6 col4" >0.5407</td>
      <td id="T_b77b4_row6_col5" class="data row6 col5" >0.3814</td>
      <td id="T_b77b4_row6_col6" class="data row6 col6" >0.3166</td>
      <td id="T_b77b4_row6_col7" class="data row6 col7" >0.3349</td>
      <td id="T_b77b4_row6_col8" class="data row6 col8" >7.0660</td>
    </tr>
    <tr>
      <th id="T_b77b4_level0_row7" class="row_heading level0 row7" >lda</th>
      <td id="T_b77b4_row7_col0" class="data row7 col0" >Linear Discriminant Analysis</td>
      <td id="T_b77b4_row7_col1" class="data row7 col1" >0.8628</td>
      <td id="T_b77b4_row7_col2" class="data row7 col2" >0.7923</td>
      <td id="T_b77b4_row7_col3" class="data row7 col3" >0.3807</td>
      <td id="T_b77b4_row7_col4" class="data row7 col4" >0.4877</td>
      <td id="T_b77b4_row7_col5" class="data row7 col5" >0.4267</td>
      <td id="T_b77b4_row7_col6" class="data row7 col6" >0.3503</td>
      <td id="T_b77b4_row7_col7" class="data row7 col7" >0.3542</td>
      <td id="T_b77b4_row7_col8" class="data row7 col8" >1.7270</td>
    </tr>
    <tr>
      <th id="T_b77b4_level0_row8" class="row_heading level0 row8" >knn</th>
      <td id="T_b77b4_row8_col0" class="data row8 col0" >K Neighbors Classifier</td>
      <td id="T_b77b4_row8_col1" class="data row8 col1" >0.8589</td>
      <td id="T_b77b4_row8_col2" class="data row8 col2" >0.5930</td>
      <td id="T_b77b4_row8_col3" class="data row8 col3" >0.0339</td>
      <td id="T_b77b4_row8_col4" class="data row8 col4" >0.3113</td>
      <td id="T_b77b4_row8_col5" class="data row8 col5" >0.0605</td>
      <td id="T_b77b4_row8_col6" class="data row8 col6" >0.0339</td>
      <td id="T_b77b4_row8_col7" class="data row8 col7" >0.0610</td>
      <td id="T_b77b4_row8_col8" class="data row8 col8" >5.4290</td>
    </tr>
    <tr>
      <th id="T_b77b4_level0_row9" class="row_heading level0 row9" >svm</th>
      <td id="T_b77b4_row9_col0" class="data row9 col0" >SVM - Linear Kernel</td>
      <td id="T_b77b4_row9_col1" class="data row9 col1" >0.8207</td>
      <td id="T_b77b4_row9_col2" class="data row9 col2" >0.0000</td>
      <td id="T_b77b4_row9_col3" class="data row9 col3" >0.2697</td>
      <td id="T_b77b4_row9_col4" class="data row9 col4" >0.5809</td>
      <td id="T_b77b4_row9_col5" class="data row9 col5" >0.2517</td>
      <td id="T_b77b4_row9_col6" class="data row9 col6" >0.1901</td>
      <td id="T_b77b4_row9_col7" class="data row9 col7" >0.2482</td>
      <td id="T_b77b4_row9_col8" class="data row9 col8" >0.7030</td>
    </tr>
    <tr>
      <th id="T_b77b4_level0_row10" class="row_heading level0 row10" >dt</th>
      <td id="T_b77b4_row10_col0" class="data row10 col0" >Decision Tree Classifier</td>
      <td id="T_b77b4_row10_col1" class="data row10 col1" >0.8130</td>
      <td id="T_b77b4_row10_col2" class="data row10 col2" >0.6270</td>
      <td id="T_b77b4_row10_col3" class="data row10 col3" >0.3725</td>
      <td id="T_b77b4_row10_col4" class="data row10 col4" >0.3288</td>
      <td id="T_b77b4_row10_col5" class="data row10 col5" >0.3487</td>
      <td id="T_b77b4_row10_col6" class="data row10 col6" >0.2402</td>
      <td id="T_b77b4_row10_col7" class="data row10 col7" >0.2411</td>
      <td id="T_b77b4_row10_col8" class="data row10 col8" >1.4520</td>
    </tr>
    <tr>
      <th id="T_b77b4_level0_row11" class="row_heading level0 row11" >nb</th>
      <td id="T_b77b4_row11_col0" class="data row11 col0" >Naive Bayes</td>
      <td id="T_b77b4_row11_col1" class="data row11 col1" >0.7807</td>
      <td id="T_b77b4_row11_col2" class="data row11 col2" >0.7412</td>
      <td id="T_b77b4_row11_col3" class="data row11 col3" >0.5862</td>
      <td id="T_b77b4_row11_col4" class="data row11 col4" >0.3261</td>
      <td id="T_b77b4_row11_col5" class="data row11 col5" >0.4187</td>
      <td id="T_b77b4_row11_col6" class="data row11 col6" >0.2971</td>
      <td id="T_b77b4_row11_col7" class="data row11 col7" >0.3167</td>
      <td id="T_b77b4_row11_col8" class="data row11 col8" >0.0860</td>
    </tr>
    <tr>
      <th id="T_b77b4_level0_row12" class="row_heading level0 row12" >qda</th>
      <td id="T_b77b4_row12_col0" class="data row12 col0" >Quadratic Discriminant Analysis</td>
      <td id="T_b77b4_row12_col1" class="data row12 col1" >0.2159</td>
      <td id="T_b77b4_row12_col2" class="data row12 col2" >0.5082</td>
      <td id="T_b77b4_row12_col3" class="data row12 col3" >0.9083</td>
      <td id="T_b77b4_row12_col4" class="data row12 col4" >0.1369</td>
      <td id="T_b77b4_row12_col5" class="data row12 col5" >0.2379</td>
      <td id="T_b77b4_row12_col6" class="data row12 col6" >0.0051</td>
      <td id="T_b77b4_row12_col7" class="data row12 col7" >0.0146</td>
      <td id="T_b77b4_row12_col8" class="data row12 col8" >2.0820</td>
    </tr>
  </tbody>
</table>






    GradientBoostingClassifier(ccp_alpha=0.0, criterion='friedman_mse', init=None,
                               learning_rate=0.1, loss='deviance', max_depth=3,
                               max_features=None, max_leaf_nodes=None,
                               min_impurity_decrease=0.0, min_impurity_split=None,
                               min_samples_leaf=1, min_samples_split=2,
                               min_weight_fraction_leaf=0.0, n_estimators=100,
                               n_iter_no_change=None, presort='deprecated',
                               random_state=5898, subsample=1.0, tol=0.0001,
                               validation_fraction=0.1, verbose=0,
                               warm_start=False)




```python
gbc_ho = create_model('gbc')
```


<style type="text/css">
#T_d5b7b_row10_col0, #T_d5b7b_row10_col1, #T_d5b7b_row10_col2, #T_d5b7b_row10_col3, #T_d5b7b_row10_col4, #T_d5b7b_row10_col5, #T_d5b7b_row10_col6 {
  background: yellow;
}
</style>
<table id="T_d5b7b_">
  <thead>
    <tr>
      <th class="blank level0" >&nbsp;</th>
      <th class="col_heading level0 col0" >Accuracy</th>
      <th class="col_heading level0 col1" >AUC</th>
      <th class="col_heading level0 col2" >Recall</th>
      <th class="col_heading level0 col3" >Prec.</th>
      <th class="col_heading level0 col4" >F1</th>
      <th class="col_heading level0 col5" >Kappa</th>
      <th class="col_heading level0 col6" >MCC</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th id="T_d5b7b_level0_row0" class="row_heading level0 row0" >0</th>
      <td id="T_d5b7b_row0_col0" class="data row0 col0" >0.8802</td>
      <td id="T_d5b7b_row0_col1" class="data row0 col1" >0.8478</td>
      <td id="T_d5b7b_row0_col2" class="data row0 col2" >0.2661</td>
      <td id="T_d5b7b_row0_col3" class="data row0 col3" >0.6304</td>
      <td id="T_d5b7b_row0_col4" class="data row0 col4" >0.3742</td>
      <td id="T_d5b7b_row0_col5" class="data row0 col5" >0.3199</td>
      <td id="T_d5b7b_row0_col6" class="data row0 col6" >0.3565</td>
    </tr>
    <tr>
      <th id="T_d5b7b_level0_row1" class="row_heading level0 row1" >1</th>
      <td id="T_d5b7b_row1_col0" class="data row1 col0" >0.8741</td>
      <td id="T_d5b7b_row1_col1" class="data row1 col1" >0.8333</td>
      <td id="T_d5b7b_row1_col2" class="data row1 col2" >0.2936</td>
      <td id="T_d5b7b_row1_col3" class="data row1 col3" >0.5614</td>
      <td id="T_d5b7b_row1_col4" class="data row1 col4" >0.3855</td>
      <td id="T_d5b7b_row1_col5" class="data row1 col5" >0.3230</td>
      <td id="T_d5b7b_row1_col6" class="data row1 col6" >0.3441</td>
    </tr>
    <tr>
      <th id="T_d5b7b_level0_row2" class="row_heading level0 row2" >2</th>
      <td id="T_d5b7b_row2_col0" class="data row2 col0" >0.8963</td>
      <td id="T_d5b7b_row2_col1" class="data row2 col1" >0.8696</td>
      <td id="T_d5b7b_row2_col2" class="data row2 col2" >0.3394</td>
      <td id="T_d5b7b_row2_col3" class="data row2 col3" >0.7551</td>
      <td id="T_d5b7b_row2_col4" class="data row2 col4" >0.4684</td>
      <td id="T_d5b7b_row2_col5" class="data row2 col5" >0.4199</td>
      <td id="T_d5b7b_row2_col6" class="data row2 col6" >0.4614</td>
    </tr>
    <tr>
      <th id="T_d5b7b_level0_row3" class="row_heading level0 row3" >3</th>
      <td id="T_d5b7b_row3_col0" class="data row3 col0" >0.8679</td>
      <td id="T_d5b7b_row3_col1" class="data row3 col1" >0.8288</td>
      <td id="T_d5b7b_row3_col2" class="data row3 col2" >0.1835</td>
      <td id="T_d5b7b_row3_col3" class="data row3 col3" >0.5263</td>
      <td id="T_d5b7b_row3_col4" class="data row3 col4" >0.2721</td>
      <td id="T_d5b7b_row3_col5" class="data row3 col5" >0.2177</td>
      <td id="T_d5b7b_row3_col6" class="data row3 col6" >0.2547</td>
    </tr>
    <tr>
      <th id="T_d5b7b_level0_row4" class="row_heading level0 row4" >4</th>
      <td id="T_d5b7b_row4_col0" class="data row4 col0" >0.8852</td>
      <td id="T_d5b7b_row4_col1" class="data row4 col1" >0.8611</td>
      <td id="T_d5b7b_row4_col2" class="data row4 col2" >0.2752</td>
      <td id="T_d5b7b_row4_col3" class="data row4 col3" >0.6818</td>
      <td id="T_d5b7b_row4_col4" class="data row4 col4" >0.3922</td>
      <td id="T_d5b7b_row4_col5" class="data row4 col5" >0.3412</td>
      <td id="T_d5b7b_row4_col6" class="data row4 col6" >0.3843</td>
    </tr>
    <tr>
      <th id="T_d5b7b_level0_row5" class="row_heading level0 row5" >5</th>
      <td id="T_d5b7b_row5_col0" class="data row5 col0" >0.8838</td>
      <td id="T_d5b7b_row5_col1" class="data row5 col1" >0.8554</td>
      <td id="T_d5b7b_row5_col2" class="data row5 col2" >0.3394</td>
      <td id="T_d5b7b_row5_col3" class="data row5 col3" >0.6271</td>
      <td id="T_d5b7b_row5_col4" class="data row5 col4" >0.4405</td>
      <td id="T_d5b7b_row5_col5" class="data row5 col5" >0.3820</td>
      <td id="T_d5b7b_row5_col6" class="data row5 col6" >0.4045</td>
    </tr>
    <tr>
      <th id="T_d5b7b_level0_row6" class="row_heading level0 row6" >6</th>
      <td id="T_d5b7b_row6_col0" class="data row6 col0" >0.8863</td>
      <td id="T_d5b7b_row6_col1" class="data row6 col1" >0.8692</td>
      <td id="T_d5b7b_row6_col2" class="data row6 col2" >0.3211</td>
      <td id="T_d5b7b_row6_col3" class="data row6 col3" >0.6604</td>
      <td id="T_d5b7b_row6_col4" class="data row6 col4" >0.4321</td>
      <td id="T_d5b7b_row6_col5" class="data row6 col5" >0.3772</td>
      <td id="T_d5b7b_row6_col6" class="data row6 col6" >0.4076</td>
    </tr>
    <tr>
      <th id="T_d5b7b_level0_row7" class="row_heading level0 row7" >7</th>
      <td id="T_d5b7b_row7_col0" class="data row7 col0" >0.8925</td>
      <td id="T_d5b7b_row7_col1" class="data row7 col1" >0.8786</td>
      <td id="T_d5b7b_row7_col2" class="data row7 col2" >0.3211</td>
      <td id="T_d5b7b_row7_col3" class="data row7 col3" >0.7292</td>
      <td id="T_d5b7b_row7_col4" class="data row7 col4" >0.4459</td>
      <td id="T_d5b7b_row7_col5" class="data row7 col5" >0.3961</td>
      <td id="T_d5b7b_row7_col6" class="data row7 col6" >0.4372</td>
    </tr>
    <tr>
      <th id="T_d5b7b_level0_row8" class="row_heading level0 row8" >8</th>
      <td id="T_d5b7b_row8_col0" class="data row8 col0" >0.9036</td>
      <td id="T_d5b7b_row8_col1" class="data row8 col1" >0.8856</td>
      <td id="T_d5b7b_row8_col2" class="data row8 col2" >0.3853</td>
      <td id="T_d5b7b_row8_col3" class="data row8 col3" >0.7925</td>
      <td id="T_d5b7b_row8_col4" class="data row8 col4" >0.5185</td>
      <td id="T_d5b7b_row8_col5" class="data row8 col5" >0.4720</td>
      <td id="T_d5b7b_row8_col6" class="data row8 col6" >0.5100</td>
    </tr>
    <tr>
      <th id="T_d5b7b_level0_row9" class="row_heading level0 row9" >9</th>
      <td id="T_d5b7b_row9_col0" class="data row9 col0" >0.8813</td>
      <td id="T_d5b7b_row9_col1" class="data row9 col1" >0.8472</td>
      <td id="T_d5b7b_row9_col2" class="data row9 col2" >0.2752</td>
      <td id="T_d5b7b_row9_col3" class="data row9 col3" >0.6383</td>
      <td id="T_d5b7b_row9_col4" class="data row9 col4" >0.3846</td>
      <td id="T_d5b7b_row9_col5" class="data row9 col5" >0.3302</td>
      <td id="T_d5b7b_row9_col6" class="data row9 col6" >0.3663</td>
    </tr>
    <tr>
      <th id="T_d5b7b_level0_row10" class="row_heading level0 row10" >Mean</th>
      <td id="T_d5b7b_row10_col0" class="data row10 col0" >0.8851</td>
      <td id="T_d5b7b_row10_col1" class="data row10 col1" >0.8577</td>
      <td id="T_d5b7b_row10_col2" class="data row10 col2" >0.3000</td>
      <td id="T_d5b7b_row10_col3" class="data row10 col3" >0.6602</td>
      <td id="T_d5b7b_row10_col4" class="data row10 col4" >0.4114</td>
      <td id="T_d5b7b_row10_col5" class="data row10 col5" >0.3579</td>
      <td id="T_d5b7b_row10_col6" class="data row10 col6" >0.3927</td>
    </tr>
    <tr>
      <th id="T_d5b7b_level0_row11" class="row_heading level0 row11" >SD</th>
      <td id="T_d5b7b_row11_col0" class="data row11 col0" >0.0099</td>
      <td id="T_d5b7b_row11_col1" class="data row11 col1" >0.0177</td>
      <td id="T_d5b7b_row11_col2" class="data row11 col2" >0.0522</td>
      <td id="T_d5b7b_row11_col3" class="data row11 col3" >0.0787</td>
      <td id="T_d5b7b_row11_col4" class="data row11 col4" >0.0630</td>
      <td id="T_d5b7b_row11_col5" class="data row11 col5" >0.0653</td>
      <td id="T_d5b7b_row11_col6" class="data row11 col6" >0.0666</td>
    </tr>
  </tbody>
</table>




```python
gbc_ho_tuned=tune_model(gbc_ho)
```


<style type="text/css">
#T_1db55_row10_col0, #T_1db55_row10_col1, #T_1db55_row10_col2, #T_1db55_row10_col3, #T_1db55_row10_col4, #T_1db55_row10_col5, #T_1db55_row10_col6 {
  background: yellow;
}
</style>
<table id="T_1db55_">
  <thead>
    <tr>
      <th class="blank level0" >&nbsp;</th>
      <th class="col_heading level0 col0" >Accuracy</th>
      <th class="col_heading level0 col1" >AUC</th>
      <th class="col_heading level0 col2" >Recall</th>
      <th class="col_heading level0 col3" >Prec.</th>
      <th class="col_heading level0 col4" >F1</th>
      <th class="col_heading level0 col5" >Kappa</th>
      <th class="col_heading level0 col6" >MCC</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th id="T_1db55_level0_row0" class="row_heading level0 row0" >0</th>
      <td id="T_1db55_row0_col0" class="data row0 col0" >0.8901</td>
      <td id="T_1db55_row0_col1" class="data row0 col1" >0.8635</td>
      <td id="T_1db55_row0_col2" class="data row0 col2" >0.3028</td>
      <td id="T_1db55_row0_col3" class="data row0 col3" >0.7174</td>
      <td id="T_1db55_row0_col4" class="data row0 col4" >0.4258</td>
      <td id="T_1db55_row0_col5" class="data row0 col5" >0.3760</td>
      <td id="T_1db55_row0_col6" class="data row0 col6" >0.4191</td>
    </tr>
    <tr>
      <th id="T_1db55_level0_row1" class="row_heading level0 row1" >1</th>
      <td id="T_1db55_row1_col0" class="data row1 col0" >0.8802</td>
      <td id="T_1db55_row1_col1" class="data row1 col1" >0.8374</td>
      <td id="T_1db55_row1_col2" class="data row1 col2" >0.2477</td>
      <td id="T_1db55_row1_col3" class="data row1 col3" >0.6429</td>
      <td id="T_1db55_row1_col4" class="data row1 col4" >0.3576</td>
      <td id="T_1db55_row1_col5" class="data row1 col5" >0.3056</td>
      <td id="T_1db55_row1_col6" class="data row1 col6" >0.3483</td>
    </tr>
    <tr>
      <th id="T_1db55_level0_row2" class="row_heading level0 row2" >2</th>
      <td id="T_1db55_row2_col0" class="data row2 col0" >0.8963</td>
      <td id="T_1db55_row2_col1" class="data row2 col1" >0.8577</td>
      <td id="T_1db55_row2_col2" class="data row2 col2" >0.3119</td>
      <td id="T_1db55_row2_col3" class="data row2 col3" >0.7907</td>
      <td id="T_1db55_row2_col4" class="data row2 col4" >0.4474</td>
      <td id="T_1db55_row2_col5" class="data row2 col5" >0.4018</td>
      <td id="T_1db55_row2_col6" class="data row2 col6" >0.4552</td>
    </tr>
    <tr>
      <th id="T_1db55_level0_row3" class="row_heading level0 row3" >3</th>
      <td id="T_1db55_row3_col0" class="data row3 col0" >0.8630</td>
      <td id="T_1db55_row3_col1" class="data row3 col1" >0.8265</td>
      <td id="T_1db55_row3_col2" class="data row3 col2" >0.1651</td>
      <td id="T_1db55_row3_col3" class="data row3 col3" >0.4737</td>
      <td id="T_1db55_row3_col4" class="data row3 col4" >0.2449</td>
      <td id="T_1db55_row3_col5" class="data row3 col5" >0.1884</td>
      <td id="T_1db55_row3_col6" class="data row3 col6" >0.2205</td>
    </tr>
    <tr>
      <th id="T_1db55_level0_row4" class="row_heading level0 row4" >4</th>
      <td id="T_1db55_row4_col0" class="data row4 col0" >0.8864</td>
      <td id="T_1db55_row4_col1" class="data row4 col1" >0.8618</td>
      <td id="T_1db55_row4_col2" class="data row4 col2" >0.2661</td>
      <td id="T_1db55_row4_col3" class="data row4 col3" >0.7073</td>
      <td id="T_1db55_row4_col4" class="data row4 col4" >0.3867</td>
      <td id="T_1db55_row4_col5" class="data row4 col5" >0.3380</td>
      <td id="T_1db55_row4_col6" class="data row4 col6" >0.3875</td>
    </tr>
    <tr>
      <th id="T_1db55_level0_row5" class="row_heading level0 row5" >5</th>
      <td id="T_1db55_row5_col0" class="data row5 col0" >0.8838</td>
      <td id="T_1db55_row5_col1" class="data row5 col1" >0.8534</td>
      <td id="T_1db55_row5_col2" class="data row5 col2" >0.3578</td>
      <td id="T_1db55_row5_col3" class="data row5 col3" >0.6190</td>
      <td id="T_1db55_row5_col4" class="data row5 col4" >0.4535</td>
      <td id="T_1db55_row5_col5" class="data row5 col5" >0.3936</td>
      <td id="T_1db55_row5_col6" class="data row5 col6" >0.4122</td>
    </tr>
    <tr>
      <th id="T_1db55_level0_row6" class="row_heading level0 row6" >6</th>
      <td id="T_1db55_row6_col0" class="data row6 col0" >0.8900</td>
      <td id="T_1db55_row6_col1" class="data row6 col1" >0.8731</td>
      <td id="T_1db55_row6_col2" class="data row6 col2" >0.3119</td>
      <td id="T_1db55_row6_col3" class="data row6 col3" >0.7083</td>
      <td id="T_1db55_row6_col4" class="data row6 col4" >0.4331</td>
      <td id="T_1db55_row6_col5" class="data row6 col5" >0.3822</td>
      <td id="T_1db55_row6_col6" class="data row6 col6" >0.4219</td>
    </tr>
    <tr>
      <th id="T_1db55_level0_row7" class="row_heading level0 row7" >7</th>
      <td id="T_1db55_row7_col0" class="data row7 col0" >0.8912</td>
      <td id="T_1db55_row7_col1" class="data row7 col1" >0.8798</td>
      <td id="T_1db55_row7_col2" class="data row7 col2" >0.3211</td>
      <td id="T_1db55_row7_col3" class="data row7 col3" >0.7143</td>
      <td id="T_1db55_row7_col4" class="data row7 col4" >0.4430</td>
      <td id="T_1db55_row7_col5" class="data row7 col5" >0.3922</td>
      <td id="T_1db55_row7_col6" class="data row7 col6" >0.4310</td>
    </tr>
    <tr>
      <th id="T_1db55_level0_row8" class="row_heading level0 row8" >8</th>
      <td id="T_1db55_row8_col0" class="data row8 col0" >0.9023</td>
      <td id="T_1db55_row8_col1" class="data row8 col1" >0.8841</td>
      <td id="T_1db55_row8_col2" class="data row8 col2" >0.3578</td>
      <td id="T_1db55_row8_col3" class="data row8 col3" >0.8125</td>
      <td id="T_1db55_row8_col4" class="data row8 col4" >0.4968</td>
      <td id="T_1db55_row8_col5" class="data row8 col5" >0.4516</td>
      <td id="T_1db55_row8_col6" class="data row8 col6" >0.4985</td>
    </tr>
    <tr>
      <th id="T_1db55_level0_row9" class="row_heading level0 row9" >9</th>
      <td id="T_1db55_row9_col0" class="data row9 col0" >0.8826</td>
      <td id="T_1db55_row9_col1" class="data row9 col1" >0.8456</td>
      <td id="T_1db55_row9_col2" class="data row9 col2" >0.2385</td>
      <td id="T_1db55_row9_col3" class="data row9 col3" >0.6842</td>
      <td id="T_1db55_row9_col4" class="data row9 col4" >0.3537</td>
      <td id="T_1db55_row9_col5" class="data row9 col5" >0.3054</td>
      <td id="T_1db55_row9_col6" class="data row9 col6" >0.3573</td>
    </tr>
    <tr>
      <th id="T_1db55_level0_row10" class="row_heading level0 row10" >Mean</th>
      <td id="T_1db55_row10_col0" class="data row10 col0" >0.8866</td>
      <td id="T_1db55_row10_col1" class="data row10 col1" >0.8583</td>
      <td id="T_1db55_row10_col2" class="data row10 col2" >0.2881</td>
      <td id="T_1db55_row10_col3" class="data row10 col3" >0.6870</td>
      <td id="T_1db55_row10_col4" class="data row10 col4" >0.4043</td>
      <td id="T_1db55_row10_col5" class="data row10 col5" >0.3535</td>
      <td id="T_1db55_row10_col6" class="data row10 col6" >0.3952</td>
    </tr>
    <tr>
      <th id="T_1db55_level0_row11" class="row_heading level0 row11" >SD</th>
      <td id="T_1db55_row11_col0" class="data row11 col0" >0.0101</td>
      <td id="T_1db55_row11_col1" class="data row11 col1" >0.0174</td>
      <td id="T_1db55_row11_col2" class="data row11 col2" >0.0564</td>
      <td id="T_1db55_row11_col3" class="data row11 col3" >0.0901</td>
      <td id="T_1db55_row11_col4" class="data row11 col4" >0.0679</td>
      <td id="T_1db55_row11_col5" class="data row11 col5" >0.0696</td>
      <td id="T_1db55_row11_col6" class="data row11 col6" >0.0717</td>
    </tr>
  </tbody>
</table>



    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_logistic.py:762: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_logistic.py:762: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_logistic.py:762: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_ridge.py:147: LinAlgWarning: Ill-conditioned matrix (rcond=2.81951e-10): result may not be accurate.
      return linalg.solve(A, Xy, sym_pos=True,
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_ridge.py:147: LinAlgWarning: Ill-conditioned matrix (rcond=2.79788e-10): result may not be accurate.
      return linalg.solve(A, Xy, sym_pos=True,
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_ridge.py:147: LinAlgWarning: Ill-conditioned matrix (rcond=3.17809e-10): result may not be accurate.
      return linalg.solve(A, Xy, sym_pos=True,
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/discriminant_analysis.py:715: UserWarning: Variables are collinear
      warnings.warn("Variables are collinear")
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/discriminant_analysis.py:715: UserWarning: Variables are collinear
      warnings.warn("Variables are collinear")
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/discriminant_analysis.py:715: UserWarning: Variables are collinear
      warnings.warn("Variables are collinear")
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_logistic.py:762: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_logistic.py:762: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_ridge.py:147: LinAlgWarning: Ill-conditioned matrix (rcond=2.79603e-10): result may not be accurate.
      return linalg.solve(A, Xy, sym_pos=True,
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_ridge.py:147: LinAlgWarning: Ill-conditioned matrix (rcond=2.76956e-10): result may not be accurate.
      return linalg.solve(A, Xy, sym_pos=True,
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/discriminant_analysis.py:715: UserWarning: Variables are collinear
      warnings.warn("Variables are collinear")
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/discriminant_analysis.py:715: UserWarning: Variables are collinear
      warnings.warn("Variables are collinear")
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/discriminant_analysis.py:715: UserWarning: Variables are collinear
      warnings.warn("Variables are collinear")
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_logistic.py:762: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_logistic.py:762: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_ridge.py:147: LinAlgWarning: Ill-conditioned matrix (rcond=2.77068e-10): result may not be accurate.
      return linalg.solve(A, Xy, sym_pos=True,
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_ridge.py:147: LinAlgWarning: Ill-conditioned matrix (rcond=2.85154e-10): result may not be accurate.
      return linalg.solve(A, Xy, sym_pos=True,
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/discriminant_analysis.py:715: UserWarning: Variables are collinear
      warnings.warn("Variables are collinear")
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/discriminant_analysis.py:715: UserWarning: Variables are collinear
      warnings.warn("Variables are collinear")
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_logistic.py:762: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_logistic.py:762: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_logistic.py:762: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_ridge.py:147: LinAlgWarning: Ill-conditioned matrix (rcond=2.75851e-10): result may not be accurate.
      return linalg.solve(A, Xy, sym_pos=True,
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_ridge.py:147: LinAlgWarning: Ill-conditioned matrix (rcond=2.77299e-10): result may not be accurate.
      return linalg.solve(A, Xy, sym_pos=True,
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_ridge.py:147: LinAlgWarning: Ill-conditioned matrix (rcond=2.31121e-10): result may not be accurate.
      return linalg.solve(A, Xy, sym_pos=True,
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/discriminant_analysis.py:715: UserWarning: Variables are collinear
      warnings.warn("Variables are collinear")
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/discriminant_analysis.py:715: UserWarning: Variables are collinear
      warnings.warn("Variables are collinear")



```python
plot_model(gbc_ho, plot='feature')
```


    
![png](output_22_0.png)
    



```python
plot_model(gbc_ho, plot='confusion_matrix')
```


    
![png](output_23_0.png)
    


# pharmacy set


```python
exp_ph = setup(ph_df.iloc[:,1:], target = 'label')
```


<style type="text/css">
#T_f7259_row5_col1, #T_f7259_row44_col1 {
  background-color: lightgreen;
}
</style>
<table id="T_f7259_">
  <thead>
    <tr>
      <th class="blank level0" >&nbsp;</th>
      <th class="col_heading level0 col0" >Description</th>
      <th class="col_heading level0 col1" >Value</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th id="T_f7259_level0_row0" class="row_heading level0 row0" >0</th>
      <td id="T_f7259_row0_col0" class="data row0 col0" >session_id</td>
      <td id="T_f7259_row0_col1" class="data row0 col1" >8098</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row1" class="row_heading level0 row1" >1</th>
      <td id="T_f7259_row1_col0" class="data row1 col0" >Target</td>
      <td id="T_f7259_row1_col1" class="data row1 col1" >label</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row2" class="row_heading level0 row2" >2</th>
      <td id="T_f7259_row2_col0" class="data row2 col0" >Target Type</td>
      <td id="T_f7259_row2_col1" class="data row2 col1" >Binary</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row3" class="row_heading level0 row3" >3</th>
      <td id="T_f7259_row3_col0" class="data row3 col0" >Label Encoded</td>
      <td id="T_f7259_row3_col1" class="data row3 col1" >None</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row4" class="row_heading level0 row4" >4</th>
      <td id="T_f7259_row4_col0" class="data row4 col0" >Original Data</td>
      <td id="T_f7259_row4_col1" class="data row4 col1" >(11565, 211)</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row5" class="row_heading level0 row5" >5</th>
      <td id="T_f7259_row5_col0" class="data row5 col0" >Missing Values</td>
      <td id="T_f7259_row5_col1" class="data row5 col1" >True</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row6" class="row_heading level0 row6" >6</th>
      <td id="T_f7259_row6_col0" class="data row6 col0" >Numeric Features</td>
      <td id="T_f7259_row6_col1" class="data row6 col1" >182</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row7" class="row_heading level0 row7" >7</th>
      <td id="T_f7259_row7_col0" class="data row7 col0" >Categorical Features</td>
      <td id="T_f7259_row7_col1" class="data row7 col1" >28</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row8" class="row_heading level0 row8" >8</th>
      <td id="T_f7259_row8_col0" class="data row8 col0" >Ordinal Features</td>
      <td id="T_f7259_row8_col1" class="data row8 col1" >False</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row9" class="row_heading level0 row9" >9</th>
      <td id="T_f7259_row9_col0" class="data row9 col0" >High Cardinality Features</td>
      <td id="T_f7259_row9_col1" class="data row9 col1" >False</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row10" class="row_heading level0 row10" >10</th>
      <td id="T_f7259_row10_col0" class="data row10 col0" >High Cardinality Method</td>
      <td id="T_f7259_row10_col1" class="data row10 col1" >None</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row11" class="row_heading level0 row11" >11</th>
      <td id="T_f7259_row11_col0" class="data row11 col0" >Transformed Train Set</td>
      <td id="T_f7259_row11_col1" class="data row11 col1" >(8095, 182)</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row12" class="row_heading level0 row12" >12</th>
      <td id="T_f7259_row12_col0" class="data row12 col0" >Transformed Test Set</td>
      <td id="T_f7259_row12_col1" class="data row12 col1" >(3470, 182)</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row13" class="row_heading level0 row13" >13</th>
      <td id="T_f7259_row13_col0" class="data row13 col0" >Shuffle Train-Test</td>
      <td id="T_f7259_row13_col1" class="data row13 col1" >True</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row14" class="row_heading level0 row14" >14</th>
      <td id="T_f7259_row14_col0" class="data row14 col0" >Stratify Train-Test</td>
      <td id="T_f7259_row14_col1" class="data row14 col1" >False</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row15" class="row_heading level0 row15" >15</th>
      <td id="T_f7259_row15_col0" class="data row15 col0" >Fold Generator</td>
      <td id="T_f7259_row15_col1" class="data row15 col1" >StratifiedKFold</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row16" class="row_heading level0 row16" >16</th>
      <td id="T_f7259_row16_col0" class="data row16 col0" >Fold Number</td>
      <td id="T_f7259_row16_col1" class="data row16 col1" >10</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row17" class="row_heading level0 row17" >17</th>
      <td id="T_f7259_row17_col0" class="data row17 col0" >CPU Jobs</td>
      <td id="T_f7259_row17_col1" class="data row17 col1" >-1</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row18" class="row_heading level0 row18" >18</th>
      <td id="T_f7259_row18_col0" class="data row18 col0" >Use GPU</td>
      <td id="T_f7259_row18_col1" class="data row18 col1" >False</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row19" class="row_heading level0 row19" >19</th>
      <td id="T_f7259_row19_col0" class="data row19 col0" >Log Experiment</td>
      <td id="T_f7259_row19_col1" class="data row19 col1" >False</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row20" class="row_heading level0 row20" >20</th>
      <td id="T_f7259_row20_col0" class="data row20 col0" >Experiment Name</td>
      <td id="T_f7259_row20_col1" class="data row20 col1" >clf-default-name</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row21" class="row_heading level0 row21" >21</th>
      <td id="T_f7259_row21_col0" class="data row21 col0" >USI</td>
      <td id="T_f7259_row21_col1" class="data row21 col1" >1398</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row22" class="row_heading level0 row22" >22</th>
      <td id="T_f7259_row22_col0" class="data row22 col0" >Imputation Type</td>
      <td id="T_f7259_row22_col1" class="data row22 col1" >simple</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row23" class="row_heading level0 row23" >23</th>
      <td id="T_f7259_row23_col0" class="data row23 col0" >Iterative Imputation Iteration</td>
      <td id="T_f7259_row23_col1" class="data row23 col1" >None</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row24" class="row_heading level0 row24" >24</th>
      <td id="T_f7259_row24_col0" class="data row24 col0" >Numeric Imputer</td>
      <td id="T_f7259_row24_col1" class="data row24 col1" >mean</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row25" class="row_heading level0 row25" >25</th>
      <td id="T_f7259_row25_col0" class="data row25 col0" >Iterative Imputation Numeric Model</td>
      <td id="T_f7259_row25_col1" class="data row25 col1" >None</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row26" class="row_heading level0 row26" >26</th>
      <td id="T_f7259_row26_col0" class="data row26 col0" >Categorical Imputer</td>
      <td id="T_f7259_row26_col1" class="data row26 col1" >constant</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row27" class="row_heading level0 row27" >27</th>
      <td id="T_f7259_row27_col0" class="data row27 col0" >Iterative Imputation Categorical Model</td>
      <td id="T_f7259_row27_col1" class="data row27 col1" >None</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row28" class="row_heading level0 row28" >28</th>
      <td id="T_f7259_row28_col0" class="data row28 col0" >Unknown Categoricals Handling</td>
      <td id="T_f7259_row28_col1" class="data row28 col1" >least_frequent</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row29" class="row_heading level0 row29" >29</th>
      <td id="T_f7259_row29_col0" class="data row29 col0" >Normalize</td>
      <td id="T_f7259_row29_col1" class="data row29 col1" >False</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row30" class="row_heading level0 row30" >30</th>
      <td id="T_f7259_row30_col0" class="data row30 col0" >Normalize Method</td>
      <td id="T_f7259_row30_col1" class="data row30 col1" >None</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row31" class="row_heading level0 row31" >31</th>
      <td id="T_f7259_row31_col0" class="data row31 col0" >Transformation</td>
      <td id="T_f7259_row31_col1" class="data row31 col1" >False</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row32" class="row_heading level0 row32" >32</th>
      <td id="T_f7259_row32_col0" class="data row32 col0" >Transformation Method</td>
      <td id="T_f7259_row32_col1" class="data row32 col1" >None</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row33" class="row_heading level0 row33" >33</th>
      <td id="T_f7259_row33_col0" class="data row33 col0" >PCA</td>
      <td id="T_f7259_row33_col1" class="data row33 col1" >False</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row34" class="row_heading level0 row34" >34</th>
      <td id="T_f7259_row34_col0" class="data row34 col0" >PCA Method</td>
      <td id="T_f7259_row34_col1" class="data row34 col1" >None</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row35" class="row_heading level0 row35" >35</th>
      <td id="T_f7259_row35_col0" class="data row35 col0" >PCA Components</td>
      <td id="T_f7259_row35_col1" class="data row35 col1" >None</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row36" class="row_heading level0 row36" >36</th>
      <td id="T_f7259_row36_col0" class="data row36 col0" >Ignore Low Variance</td>
      <td id="T_f7259_row36_col1" class="data row36 col1" >False</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row37" class="row_heading level0 row37" >37</th>
      <td id="T_f7259_row37_col0" class="data row37 col0" >Combine Rare Levels</td>
      <td id="T_f7259_row37_col1" class="data row37 col1" >False</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row38" class="row_heading level0 row38" >38</th>
      <td id="T_f7259_row38_col0" class="data row38 col0" >Rare Level Threshold</td>
      <td id="T_f7259_row38_col1" class="data row38 col1" >None</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row39" class="row_heading level0 row39" >39</th>
      <td id="T_f7259_row39_col0" class="data row39 col0" >Numeric Binning</td>
      <td id="T_f7259_row39_col1" class="data row39 col1" >False</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row40" class="row_heading level0 row40" >40</th>
      <td id="T_f7259_row40_col0" class="data row40 col0" >Remove Outliers</td>
      <td id="T_f7259_row40_col1" class="data row40 col1" >False</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row41" class="row_heading level0 row41" >41</th>
      <td id="T_f7259_row41_col0" class="data row41 col0" >Outliers Threshold</td>
      <td id="T_f7259_row41_col1" class="data row41 col1" >None</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row42" class="row_heading level0 row42" >42</th>
      <td id="T_f7259_row42_col0" class="data row42 col0" >Remove Multicollinearity</td>
      <td id="T_f7259_row42_col1" class="data row42 col1" >False</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row43" class="row_heading level0 row43" >43</th>
      <td id="T_f7259_row43_col0" class="data row43 col0" >Multicollinearity Threshold</td>
      <td id="T_f7259_row43_col1" class="data row43 col1" >None</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row44" class="row_heading level0 row44" >44</th>
      <td id="T_f7259_row44_col0" class="data row44 col0" >Remove Perfect Collinearity</td>
      <td id="T_f7259_row44_col1" class="data row44 col1" >True</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row45" class="row_heading level0 row45" >45</th>
      <td id="T_f7259_row45_col0" class="data row45 col0" >Clustering</td>
      <td id="T_f7259_row45_col1" class="data row45 col1" >False</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row46" class="row_heading level0 row46" >46</th>
      <td id="T_f7259_row46_col0" class="data row46 col0" >Clustering Iteration</td>
      <td id="T_f7259_row46_col1" class="data row46 col1" >None</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row47" class="row_heading level0 row47" >47</th>
      <td id="T_f7259_row47_col0" class="data row47 col0" >Polynomial Features</td>
      <td id="T_f7259_row47_col1" class="data row47 col1" >False</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row48" class="row_heading level0 row48" >48</th>
      <td id="T_f7259_row48_col0" class="data row48 col0" >Polynomial Degree</td>
      <td id="T_f7259_row48_col1" class="data row48 col1" >None</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row49" class="row_heading level0 row49" >49</th>
      <td id="T_f7259_row49_col0" class="data row49 col0" >Trignometry Features</td>
      <td id="T_f7259_row49_col1" class="data row49 col1" >False</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row50" class="row_heading level0 row50" >50</th>
      <td id="T_f7259_row50_col0" class="data row50 col0" >Polynomial Threshold</td>
      <td id="T_f7259_row50_col1" class="data row50 col1" >None</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row51" class="row_heading level0 row51" >51</th>
      <td id="T_f7259_row51_col0" class="data row51 col0" >Group Features</td>
      <td id="T_f7259_row51_col1" class="data row51 col1" >False</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row52" class="row_heading level0 row52" >52</th>
      <td id="T_f7259_row52_col0" class="data row52 col0" >Feature Selection</td>
      <td id="T_f7259_row52_col1" class="data row52 col1" >False</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row53" class="row_heading level0 row53" >53</th>
      <td id="T_f7259_row53_col0" class="data row53 col0" >Feature Selection Method</td>
      <td id="T_f7259_row53_col1" class="data row53 col1" >classic</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row54" class="row_heading level0 row54" >54</th>
      <td id="T_f7259_row54_col0" class="data row54 col0" >Features Selection Threshold</td>
      <td id="T_f7259_row54_col1" class="data row54 col1" >None</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row55" class="row_heading level0 row55" >55</th>
      <td id="T_f7259_row55_col0" class="data row55 col0" >Feature Interaction</td>
      <td id="T_f7259_row55_col1" class="data row55 col1" >False</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row56" class="row_heading level0 row56" >56</th>
      <td id="T_f7259_row56_col0" class="data row56 col0" >Feature Ratio</td>
      <td id="T_f7259_row56_col1" class="data row56 col1" >False</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row57" class="row_heading level0 row57" >57</th>
      <td id="T_f7259_row57_col0" class="data row57 col0" >Interaction Threshold</td>
      <td id="T_f7259_row57_col1" class="data row57 col1" >None</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row58" class="row_heading level0 row58" >58</th>
      <td id="T_f7259_row58_col0" class="data row58 col0" >Fix Imbalance</td>
      <td id="T_f7259_row58_col1" class="data row58 col1" >False</td>
    </tr>
    <tr>
      <th id="T_f7259_level0_row59" class="row_heading level0 row59" >59</th>
      <td id="T_f7259_row59_col0" class="data row59 col0" >Fix Imbalance Method</td>
      <td id="T_f7259_row59_col1" class="data row59 col1" >SMOTE</td>
    </tr>
  </tbody>
</table>




```python
compare_models()
```


<style type="text/css">
#T_62b73_ th {
  text-align: left;
}
#T_62b73_row0_col0, #T_62b73_row0_col2, #T_62b73_row0_col3, #T_62b73_row0_col5, #T_62b73_row0_col6, #T_62b73_row0_col7, #T_62b73_row1_col0, #T_62b73_row1_col1, #T_62b73_row1_col3, #T_62b73_row1_col4, #T_62b73_row1_col5, #T_62b73_row1_col6, #T_62b73_row2_col0, #T_62b73_row2_col1, #T_62b73_row2_col2, #T_62b73_row2_col3, #T_62b73_row2_col4, #T_62b73_row2_col5, #T_62b73_row2_col6, #T_62b73_row2_col7, #T_62b73_row3_col0, #T_62b73_row3_col1, #T_62b73_row3_col2, #T_62b73_row3_col3, #T_62b73_row3_col4, #T_62b73_row3_col5, #T_62b73_row3_col6, #T_62b73_row3_col7, #T_62b73_row4_col0, #T_62b73_row4_col1, #T_62b73_row4_col2, #T_62b73_row4_col3, #T_62b73_row4_col4, #T_62b73_row4_col5, #T_62b73_row4_col6, #T_62b73_row4_col7, #T_62b73_row5_col0, #T_62b73_row5_col1, #T_62b73_row5_col2, #T_62b73_row5_col3, #T_62b73_row5_col4, #T_62b73_row5_col5, #T_62b73_row5_col6, #T_62b73_row5_col7, #T_62b73_row6_col0, #T_62b73_row6_col1, #T_62b73_row6_col2, #T_62b73_row6_col3, #T_62b73_row6_col4, #T_62b73_row6_col5, #T_62b73_row6_col6, #T_62b73_row6_col7, #T_62b73_row7_col0, #T_62b73_row7_col1, #T_62b73_row7_col2, #T_62b73_row7_col3, #T_62b73_row7_col4, #T_62b73_row7_col5, #T_62b73_row7_col6, #T_62b73_row7_col7, #T_62b73_row8_col0, #T_62b73_row8_col1, #T_62b73_row8_col2, #T_62b73_row8_col3, #T_62b73_row8_col4, #T_62b73_row8_col5, #T_62b73_row8_col6, #T_62b73_row8_col7, #T_62b73_row9_col0, #T_62b73_row9_col1, #T_62b73_row9_col2, #T_62b73_row9_col3, #T_62b73_row9_col4, #T_62b73_row9_col5, #T_62b73_row9_col6, #T_62b73_row9_col7, #T_62b73_row10_col0, #T_62b73_row10_col1, #T_62b73_row10_col2, #T_62b73_row10_col3, #T_62b73_row10_col4, #T_62b73_row10_col5, #T_62b73_row10_col6, #T_62b73_row10_col7, #T_62b73_row11_col0, #T_62b73_row11_col1, #T_62b73_row11_col2, #T_62b73_row11_col3, #T_62b73_row11_col4, #T_62b73_row11_col5, #T_62b73_row11_col7, #T_62b73_row12_col0, #T_62b73_row12_col1, #T_62b73_row12_col2, #T_62b73_row12_col4, #T_62b73_row12_col6, #T_62b73_row12_col7 {
  text-align: left;
}
#T_62b73_row0_col1, #T_62b73_row0_col4, #T_62b73_row1_col2, #T_62b73_row1_col7, #T_62b73_row11_col6, #T_62b73_row12_col3, #T_62b73_row12_col5 {
  text-align: left;
  background-color: yellow;
}
#T_62b73_row0_col8, #T_62b73_row1_col8, #T_62b73_row2_col8, #T_62b73_row3_col8, #T_62b73_row4_col8, #T_62b73_row5_col8, #T_62b73_row6_col8, #T_62b73_row7_col8, #T_62b73_row8_col8, #T_62b73_row10_col8, #T_62b73_row11_col8, #T_62b73_row12_col8 {
  text-align: left;
  background-color: lightgrey;
}
#T_62b73_row9_col8 {
  text-align: left;
  background-color: yellow;
  background-color: lightgrey;
}
</style>
<table id="T_62b73_">
  <thead>
    <tr>
      <th class="blank level0" >&nbsp;</th>
      <th class="col_heading level0 col0" >Model</th>
      <th class="col_heading level0 col1" >Accuracy</th>
      <th class="col_heading level0 col2" >AUC</th>
      <th class="col_heading level0 col3" >Recall</th>
      <th class="col_heading level0 col4" >Prec.</th>
      <th class="col_heading level0 col5" >F1</th>
      <th class="col_heading level0 col6" >Kappa</th>
      <th class="col_heading level0 col7" >MCC</th>
      <th class="col_heading level0 col8" >TT (Sec)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th id="T_62b73_level0_row0" class="row_heading level0 row0" >et</th>
      <td id="T_62b73_row0_col0" class="data row0 col0" >Extra Trees Classifier</td>
      <td id="T_62b73_row0_col1" class="data row0 col1" >0.8661</td>
      <td id="T_62b73_row0_col2" class="data row0 col2" >0.6451</td>
      <td id="T_62b73_row0_col3" class="data row0 col3" >0.0237</td>
      <td id="T_62b73_row0_col4" class="data row0 col4" >0.7139</td>
      <td id="T_62b73_row0_col5" class="data row0 col5" >0.0454</td>
      <td id="T_62b73_row0_col6" class="data row0 col6" >0.0371</td>
      <td id="T_62b73_row0_col7" class="data row0 col7" >0.1094</td>
      <td id="T_62b73_row0_col8" class="data row0 col8" >0.8100</td>
    </tr>
    <tr>
      <th id="T_62b73_level0_row1" class="row_heading level0 row1" >gbc</th>
      <td id="T_62b73_row1_col0" class="data row1 col0" >Gradient Boosting Classifier</td>
      <td id="T_62b73_row1_col1" class="data row1 col1" >0.8660</td>
      <td id="T_62b73_row1_col2" class="data row1 col2" >0.6859</td>
      <td id="T_62b73_row1_col3" class="data row1 col3" >0.0547</td>
      <td id="T_62b73_row1_col4" class="data row1 col4" >0.5352</td>
      <td id="T_62b73_row1_col5" class="data row1 col5" >0.0977</td>
      <td id="T_62b73_row1_col6" class="data row1 col6" >0.0764</td>
      <td id="T_62b73_row1_col7" class="data row1 col7" >0.1367</td>
      <td id="T_62b73_row1_col8" class="data row1 col8" >8.4180</td>
    </tr>
    <tr>
      <th id="T_62b73_level0_row2" class="row_heading level0 row2" >rf</th>
      <td id="T_62b73_row2_col0" class="data row2 col0" >Random Forest Classifier</td>
      <td id="T_62b73_row2_col1" class="data row2 col1" >0.8650</td>
      <td id="T_62b73_row2_col2" class="data row2 col2" >0.6556</td>
      <td id="T_62b73_row2_col3" class="data row2 col3" >0.0273</td>
      <td id="T_62b73_row2_col4" class="data row2 col4" >0.5287</td>
      <td id="T_62b73_row2_col5" class="data row2 col5" >0.0518</td>
      <td id="T_62b73_row2_col6" class="data row2 col6" >0.0397</td>
      <td id="T_62b73_row2_col7" class="data row2 col7" >0.0966</td>
      <td id="T_62b73_row2_col8" class="data row2 col8" >2.7240</td>
    </tr>
    <tr>
      <th id="T_62b73_level0_row3" class="row_heading level0 row3" >ridge</th>
      <td id="T_62b73_row3_col0" class="data row3 col0" >Ridge Classifier</td>
      <td id="T_62b73_row3_col1" class="data row3 col1" >0.8640</td>
      <td id="T_62b73_row3_col2" class="data row3 col2" >0.0000</td>
      <td id="T_62b73_row3_col3" class="data row3 col3" >0.0155</td>
      <td id="T_62b73_row3_col4" class="data row3 col4" >0.4088</td>
      <td id="T_62b73_row3_col5" class="data row3 col5" >0.0297</td>
      <td id="T_62b73_row3_col6" class="data row3 col6" >0.0214</td>
      <td id="T_62b73_row3_col7" class="data row3 col7" >0.0613</td>
      <td id="T_62b73_row3_col8" class="data row3 col8" >0.0350</td>
    </tr>
    <tr>
      <th id="T_62b73_level0_row4" class="row_heading level0 row4" >lr</th>
      <td id="T_62b73_row4_col0" class="data row4 col0" >Logistic Regression</td>
      <td id="T_62b73_row4_col1" class="data row4 col1" >0.8628</td>
      <td id="T_62b73_row4_col2" class="data row4 col2" >0.6708</td>
      <td id="T_62b73_row4_col3" class="data row4 col3" >0.0328</td>
      <td id="T_62b73_row4_col4" class="data row4 col4" >0.4470</td>
      <td id="T_62b73_row4_col5" class="data row4 col5" >0.0608</td>
      <td id="T_62b73_row4_col6" class="data row4 col6" >0.0424</td>
      <td id="T_62b73_row4_col7" class="data row4 col7" >0.0894</td>
      <td id="T_62b73_row4_col8" class="data row4 col8" >2.1940</td>
    </tr>
    <tr>
      <th id="T_62b73_level0_row5" class="row_heading level0 row5" >lightgbm</th>
      <td id="T_62b73_row5_col0" class="data row5 col0" >Light Gradient Boosting Machine</td>
      <td id="T_62b73_row5_col1" class="data row5 col1" >0.8623</td>
      <td id="T_62b73_row5_col2" class="data row5 col2" >0.6760</td>
      <td id="T_62b73_row5_col3" class="data row5 col3" >0.0537</td>
      <td id="T_62b73_row5_col4" class="data row5 col4" >0.4543</td>
      <td id="T_62b73_row5_col5" class="data row5 col5" >0.0955</td>
      <td id="T_62b73_row5_col6" class="data row5 col6" >0.0682</td>
      <td id="T_62b73_row5_col7" class="data row5 col7" >0.1171</td>
      <td id="T_62b73_row5_col8" class="data row5 col8" >0.8230</td>
    </tr>
    <tr>
      <th id="T_62b73_level0_row6" class="row_heading level0 row6" >lda</th>
      <td id="T_62b73_row6_col0" class="data row6 col0" >Linear Discriminant Analysis</td>
      <td id="T_62b73_row6_col1" class="data row6 col1" >0.8611</td>
      <td id="T_62b73_row6_col2" class="data row6 col2" >0.6695</td>
      <td id="T_62b73_row6_col3" class="data row6 col3" >0.0610</td>
      <td id="T_62b73_row6_col4" class="data row6 col4" >0.4372</td>
      <td id="T_62b73_row6_col5" class="data row6 col5" >0.1064</td>
      <td id="T_62b73_row6_col6" class="data row6 col6" >0.0748</td>
      <td id="T_62b73_row6_col7" class="data row6 col7" >0.1204</td>
      <td id="T_62b73_row6_col8" class="data row6 col8" >0.1840</td>
    </tr>
    <tr>
      <th id="T_62b73_level0_row7" class="row_heading level0 row7" >ada</th>
      <td id="T_62b73_row7_col0" class="data row7 col0" >Ada Boost Classifier</td>
      <td id="T_62b73_row7_col1" class="data row7 col1" >0.8584</td>
      <td id="T_62b73_row7_col2" class="data row7 col2" >0.6718</td>
      <td id="T_62b73_row7_col3" class="data row7 col3" >0.0564</td>
      <td id="T_62b73_row7_col4" class="data row7 col4" >0.3477</td>
      <td id="T_62b73_row7_col5" class="data row7 col5" >0.0966</td>
      <td id="T_62b73_row7_col6" class="data row7 col6" >0.0628</td>
      <td id="T_62b73_row7_col7" class="data row7 col7" >0.0937</td>
      <td id="T_62b73_row7_col8" class="data row7 col8" >1.6980</td>
    </tr>
    <tr>
      <th id="T_62b73_level0_row8" class="row_heading level0 row8" >knn</th>
      <td id="T_62b73_row8_col0" class="data row8 col0" >K Neighbors Classifier</td>
      <td id="T_62b73_row8_col1" class="data row8 col1" >0.8555</td>
      <td id="T_62b73_row8_col2" class="data row8 col2" >0.5724</td>
      <td id="T_62b73_row8_col3" class="data row8 col3" >0.0382</td>
      <td id="T_62b73_row8_col4" class="data row8 col4" >0.2515</td>
      <td id="T_62b73_row8_col5" class="data row8 col5" >0.0659</td>
      <td id="T_62b73_row8_col6" class="data row8 col6" >0.0340</td>
      <td id="T_62b73_row8_col7" class="data row8 col7" >0.0509</td>
      <td id="T_62b73_row8_col8" class="data row8 col8" >1.6680</td>
    </tr>
    <tr>
      <th id="T_62b73_level0_row9" class="row_heading level0 row9" >nb</th>
      <td id="T_62b73_row9_col0" class="data row9 col0" >Naive Bayes</td>
      <td id="T_62b73_row9_col1" class="data row9 col1" >0.8273</td>
      <td id="T_62b73_row9_col2" class="data row9 col2" >0.6025</td>
      <td id="T_62b73_row9_col3" class="data row9 col3" >0.1255</td>
      <td id="T_62b73_row9_col4" class="data row9 col4" >0.3082</td>
      <td id="T_62b73_row9_col5" class="data row9 col5" >0.1396</td>
      <td id="T_62b73_row9_col6" class="data row9 col6" >0.0743</td>
      <td id="T_62b73_row9_col7" class="data row9 col7" >0.0983</td>
      <td id="T_62b73_row9_col8" class="data row9 col8" >0.0300</td>
    </tr>
    <tr>
      <th id="T_62b73_level0_row10" class="row_heading level0 row10" >svm</th>
      <td id="T_62b73_row10_col0" class="data row10 col0" >SVM - Linear Kernel</td>
      <td id="T_62b73_row10_col1" class="data row10 col1" >0.7884</td>
      <td id="T_62b73_row10_col2" class="data row10 col2" >0.0000</td>
      <td id="T_62b73_row10_col3" class="data row10 col3" >0.1765</td>
      <td id="T_62b73_row10_col4" class="data row10 col4" >0.2110</td>
      <td id="T_62b73_row10_col5" class="data row10 col5" >0.1755</td>
      <td id="T_62b73_row10_col6" class="data row10 col6" >0.0665</td>
      <td id="T_62b73_row10_col7" class="data row10 col7" >0.0702</td>
      <td id="T_62b73_row10_col8" class="data row10 col8" >0.0560</td>
    </tr>
    <tr>
      <th id="T_62b73_level0_row11" class="row_heading level0 row11" >dt</th>
      <td id="T_62b73_row11_col0" class="data row11 col0" >Decision Tree Classifier</td>
      <td id="T_62b73_row11_col1" class="data row11 col1" >0.7738</td>
      <td id="T_62b73_row11_col2" class="data row11 col2" >0.5502</td>
      <td id="T_62b73_row11_col3" class="data row11 col3" >0.2402</td>
      <td id="T_62b73_row11_col4" class="data row11 col4" >0.2105</td>
      <td id="T_62b73_row11_col5" class="data row11 col5" >0.2241</td>
      <td id="T_62b73_row11_col6" class="data row11 col6" >0.0926</td>
      <td id="T_62b73_row11_col7" class="data row11 col7" >0.0929</td>
      <td id="T_62b73_row11_col8" class="data row11 col8" >0.6730</td>
    </tr>
    <tr>
      <th id="T_62b73_level0_row12" class="row_heading level0 row12" >qda</th>
      <td id="T_62b73_row12_col0" class="data row12 col0" >Quadratic Discriminant Analysis</td>
      <td id="T_62b73_row12_col1" class="data row12 col1" >0.1391</td>
      <td id="T_62b73_row12_col2" class="data row12 col2" >0.4996</td>
      <td id="T_62b73_row12_col3" class="data row12 col3" >0.9945</td>
      <td id="T_62b73_row12_col4" class="data row12 col4" >0.1357</td>
      <td id="T_62b73_row12_col5" class="data row12 col5" >0.2388</td>
      <td id="T_62b73_row12_col6" class="data row12 col6" >-0.0002</td>
      <td id="T_62b73_row12_col7" class="data row12 col7" >-0.0036</td>
      <td id="T_62b73_row12_col8" class="data row12 col8" >0.1510</td>
    </tr>
  </tbody>
</table>






    ExtraTreesClassifier(bootstrap=False, ccp_alpha=0.0, class_weight=None,
                         criterion='gini', max_depth=None, max_features='auto',
                         max_leaf_nodes=None, max_samples=None,
                         min_impurity_decrease=0.0, min_impurity_split=None,
                         min_samples_leaf=1, min_samples_split=2,
                         min_weight_fraction_leaf=0.0, n_estimators=100, n_jobs=-1,
                         oob_score=False, random_state=8098, verbose=0,
                         warm_start=False)




```python
gbc_ph = create_model('gbc')
```


<style type="text/css">
#T_e240f_row10_col0, #T_e240f_row10_col1, #T_e240f_row10_col2, #T_e240f_row10_col3, #T_e240f_row10_col4, #T_e240f_row10_col5, #T_e240f_row10_col6 {
  background: yellow;
}
</style>
<table id="T_e240f_">
  <thead>
    <tr>
      <th class="blank level0" >&nbsp;</th>
      <th class="col_heading level0 col0" >Accuracy</th>
      <th class="col_heading level0 col1" >AUC</th>
      <th class="col_heading level0 col2" >Recall</th>
      <th class="col_heading level0 col3" >Prec.</th>
      <th class="col_heading level0 col4" >F1</th>
      <th class="col_heading level0 col5" >Kappa</th>
      <th class="col_heading level0 col6" >MCC</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th id="T_e240f_level0_row0" class="row_heading level0 row0" >0</th>
      <td id="T_e240f_row0_col0" class="data row0 col0" >0.8691</td>
      <td id="T_e240f_row0_col1" class="data row0 col1" >0.7666</td>
      <td id="T_e240f_row0_col2" class="data row0 col2" >0.0636</td>
      <td id="T_e240f_row0_col3" class="data row0 col3" >0.7000</td>
      <td id="T_e240f_row0_col4" class="data row0 col4" >0.1167</td>
      <td id="T_e240f_row0_col5" class="data row0 col5" >0.0962</td>
      <td id="T_e240f_row0_col6" class="data row0 col6" >0.1841</td>
    </tr>
    <tr>
      <th id="T_e240f_level0_row1" class="row_heading level0 row1" >1</th>
      <td id="T_e240f_row1_col0" class="data row1 col0" >0.8667</td>
      <td id="T_e240f_row1_col1" class="data row1 col1" >0.6316</td>
      <td id="T_e240f_row1_col2" class="data row1 col2" >0.0455</td>
      <td id="T_e240f_row1_col3" class="data row1 col3" >0.6250</td>
      <td id="T_e240f_row1_col4" class="data row1 col4" >0.0847</td>
      <td id="T_e240f_row1_col5" class="data row1 col5" >0.0676</td>
      <td id="T_e240f_row1_col6" class="data row1 col6" >0.1426</td>
    </tr>
    <tr>
      <th id="T_e240f_level0_row2" class="row_heading level0 row2" >2</th>
      <td id="T_e240f_row2_col0" class="data row2 col0" >0.8728</td>
      <td id="T_e240f_row2_col1" class="data row2 col1" >0.7406</td>
      <td id="T_e240f_row2_col2" class="data row2 col2" >0.1091</td>
      <td id="T_e240f_row2_col3" class="data row2 col3" >0.7059</td>
      <td id="T_e240f_row2_col4" class="data row2 col4" >0.1890</td>
      <td id="T_e240f_row2_col5" class="data row2 col5" >0.1584</td>
      <td id="T_e240f_row2_col6" class="data row2 col6" >0.2436</td>
    </tr>
    <tr>
      <th id="T_e240f_level0_row3" class="row_heading level0 row3" >3</th>
      <td id="T_e240f_row3_col0" class="data row3 col0" >0.8605</td>
      <td id="T_e240f_row3_col1" class="data row3 col1" >0.6661</td>
      <td id="T_e240f_row3_col2" class="data row3 col2" >0.0091</td>
      <td id="T_e240f_row3_col3" class="data row3 col3" >0.2000</td>
      <td id="T_e240f_row3_col4" class="data row3 col4" >0.0174</td>
      <td id="T_e240f_row3_col5" class="data row3 col5" >0.0056</td>
      <td id="T_e240f_row3_col6" class="data row3 col6" >0.0148</td>
    </tr>
    <tr>
      <th id="T_e240f_level0_row4" class="row_heading level0 row4" >4</th>
      <td id="T_e240f_row4_col0" class="data row4 col0" >0.8667</td>
      <td id="T_e240f_row4_col1" class="data row4 col1" >0.6632</td>
      <td id="T_e240f_row4_col2" class="data row4 col2" >0.0545</td>
      <td id="T_e240f_row4_col3" class="data row4 col3" >0.6000</td>
      <td id="T_e240f_row4_col4" class="data row4 col4" >0.1000</td>
      <td id="T_e240f_row4_col5" class="data row4 col5" >0.0792</td>
      <td id="T_e240f_row4_col6" class="data row4 col6" >0.1515</td>
    </tr>
    <tr>
      <th id="T_e240f_level0_row5" class="row_heading level0 row5" >5</th>
      <td id="T_e240f_row5_col0" class="data row5 col0" >0.8714</td>
      <td id="T_e240f_row5_col1" class="data row5 col1" >0.6983</td>
      <td id="T_e240f_row5_col2" class="data row5 col2" >0.1193</td>
      <td id="T_e240f_row5_col3" class="data row5 col3" >0.6190</td>
      <td id="T_e240f_row5_col4" class="data row5 col4" >0.2000</td>
      <td id="T_e240f_row5_col5" class="data row5 col5" >0.1636</td>
      <td id="T_e240f_row5_col6" class="data row5 col6" >0.2316</td>
    </tr>
    <tr>
      <th id="T_e240f_level0_row6" class="row_heading level0 row6" >6</th>
      <td id="T_e240f_row6_col0" class="data row6 col0" >0.8578</td>
      <td id="T_e240f_row6_col1" class="data row6 col1" >0.6994</td>
      <td id="T_e240f_row6_col2" class="data row6 col2" >0.0364</td>
      <td id="T_e240f_row6_col3" class="data row6 col3" >0.3077</td>
      <td id="T_e240f_row6_col4" class="data row6 col4" >0.0650</td>
      <td id="T_e240f_row6_col5" class="data row6 col5" >0.0374</td>
      <td id="T_e240f_row6_col6" class="data row6 col6" >0.0640</td>
    </tr>
    <tr>
      <th id="T_e240f_level0_row7" class="row_heading level0 row7" >7</th>
      <td id="T_e240f_row7_col0" class="data row7 col0" >0.8690</td>
      <td id="T_e240f_row7_col1" class="data row7 col1" >0.6500</td>
      <td id="T_e240f_row7_col2" class="data row7 col2" >0.0545</td>
      <td id="T_e240f_row7_col3" class="data row7 col3" >0.7500</td>
      <td id="T_e240f_row7_col4" class="data row7 col4" >0.1017</td>
      <td id="T_e240f_row7_col5" class="data row7 col5" >0.0848</td>
      <td id="T_e240f_row7_col6" class="data row7 col6" >0.1790</td>
    </tr>
    <tr>
      <th id="T_e240f_level0_row8" class="row_heading level0 row8" >8</th>
      <td id="T_e240f_row8_col0" class="data row8 col0" >0.8628</td>
      <td id="T_e240f_row8_col1" class="data row8 col1" >0.6825</td>
      <td id="T_e240f_row8_col2" class="data row8 col2" >0.0364</td>
      <td id="T_e240f_row8_col3" class="data row8 col3" >0.4444</td>
      <td id="T_e240f_row8_col4" class="data row8 col4" >0.0672</td>
      <td id="T_e240f_row8_col5" class="data row8 col5" >0.0476</td>
      <td id="T_e240f_row8_col6" class="data row8 col6" >0.0955</td>
    </tr>
    <tr>
      <th id="T_e240f_level0_row9" class="row_heading level0 row9" >9</th>
      <td id="T_e240f_row9_col0" class="data row9 col0" >0.8628</td>
      <td id="T_e240f_row9_col1" class="data row9 col1" >0.6607</td>
      <td id="T_e240f_row9_col2" class="data row9 col2" >0.0182</td>
      <td id="T_e240f_row9_col3" class="data row9 col3" >0.4000</td>
      <td id="T_e240f_row9_col4" class="data row9 col4" >0.0348</td>
      <td id="T_e240f_row9_col5" class="data row9 col5" >0.0232</td>
      <td id="T_e240f_row9_col6" class="data row9 col6" >0.0607</td>
    </tr>
    <tr>
      <th id="T_e240f_level0_row10" class="row_heading level0 row10" >Mean</th>
      <td id="T_e240f_row10_col0" class="data row10 col0" >0.8660</td>
      <td id="T_e240f_row10_col1" class="data row10 col1" >0.6859</td>
      <td id="T_e240f_row10_col2" class="data row10 col2" >0.0547</td>
      <td id="T_e240f_row10_col3" class="data row10 col3" >0.5352</td>
      <td id="T_e240f_row10_col4" class="data row10 col4" >0.0977</td>
      <td id="T_e240f_row10_col5" class="data row10 col5" >0.0764</td>
      <td id="T_e240f_row10_col6" class="data row10 col6" >0.1367</td>
    </tr>
    <tr>
      <th id="T_e240f_level0_row11" class="row_heading level0 row11" >SD</th>
      <td id="T_e240f_row11_col0" class="data row11 col0" >0.0046</td>
      <td id="T_e240f_row11_col1" class="data row11 col1" >0.0395</td>
      <td id="T_e240f_row11_col2" class="data row11 col2" >0.0337</td>
      <td id="T_e240f_row11_col3" class="data row11 col3" >0.1767</td>
      <td id="T_e240f_row11_col4" class="data row11 col4" >0.0563</td>
      <td id="T_e240f_row11_col5" class="data row11 col5" >0.0501</td>
      <td id="T_e240f_row11_col6" class="data row11 col6" >0.0724</td>
    </tr>
  </tbody>
</table>



    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_logistic.py:762: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_logistic.py:762: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_logistic.py:762: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_ridge.py:147: LinAlgWarning: Ill-conditioned matrix (rcond=1.18337e-11): result may not be accurate.
      return linalg.solve(A, Xy, sym_pos=True,
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_ridge.py:147: LinAlgWarning: Ill-conditioned matrix (rcond=1.16863e-11): result may not be accurate.
      return linalg.solve(A, Xy, sym_pos=True,
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/discriminant_analysis.py:715: UserWarning: Variables are collinear
      warnings.warn("Variables are collinear")
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/metrics/_classification.py:846: RuntimeWarning: invalid value encountered in double_scalars
      mcc = cov_ytyp / np.sqrt(cov_ytyt * cov_ypyp)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/discriminant_analysis.py:715: UserWarning: Variables are collinear
      warnings.warn("Variables are collinear")
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/discriminant_analysis.py:715: UserWarning: Variables are collinear
      warnings.warn("Variables are collinear")
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_logistic.py:762: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_logistic.py:762: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_ridge.py:147: LinAlgWarning: Ill-conditioned matrix (rcond=1.15001e-11): result may not be accurate.
      return linalg.solve(A, Xy, sym_pos=True,
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_ridge.py:147: LinAlgWarning: Ill-conditioned matrix (rcond=8.81595e-12): result may not be accurate.
      return linalg.solve(A, Xy, sym_pos=True,
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_ridge.py:147: LinAlgWarning: Ill-conditioned matrix (rcond=2.40482e-11): result may not be accurate.
      return linalg.solve(A, Xy, sym_pos=True,
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/discriminant_analysis.py:715: UserWarning: Variables are collinear
      warnings.warn("Variables are collinear")
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/metrics/_classification.py:846: RuntimeWarning: invalid value encountered in double_scalars
      mcc = cov_ytyp / np.sqrt(cov_ytyt * cov_ypyp)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/discriminant_analysis.py:715: UserWarning: Variables are collinear
      warnings.warn("Variables are collinear")
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_logistic.py:762: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_logistic.py:762: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_logistic.py:762: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_ridge.py:147: LinAlgWarning: Ill-conditioned matrix (rcond=1.36968e-11): result may not be accurate.
      return linalg.solve(A, Xy, sym_pos=True,
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/metrics/_classification.py:1221: UndefinedMetricWarning: Precision is ill-defined and being set to 0.0 due to no predicted samples. Use `zero_division` parameter to control this behavior.
      _warn_prf(average, modifier, msg_start, len(result))
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/metrics/_classification.py:846: RuntimeWarning: invalid value encountered in double_scalars
      mcc = cov_ytyp / np.sqrt(cov_ytyt * cov_ypyp)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_ridge.py:147: LinAlgWarning: Ill-conditioned matrix (rcond=1.647e-11): result may not be accurate.
      return linalg.solve(A, Xy, sym_pos=True,
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/discriminant_analysis.py:715: UserWarning: Variables are collinear
      warnings.warn("Variables are collinear")
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/discriminant_analysis.py:715: UserWarning: Variables are collinear
      warnings.warn("Variables are collinear")
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/discriminant_analysis.py:715: UserWarning: Variables are collinear
      warnings.warn("Variables are collinear")
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_logistic.py:762: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_logistic.py:762: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_ridge.py:147: LinAlgWarning: Ill-conditioned matrix (rcond=1.1494e-11): result may not be accurate.
      return linalg.solve(A, Xy, sym_pos=True,
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/metrics/_classification.py:1221: UndefinedMetricWarning: Precision is ill-defined and being set to 0.0 due to no predicted samples. Use `zero_division` parameter to control this behavior.
      _warn_prf(average, modifier, msg_start, len(result))
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/metrics/_classification.py:846: RuntimeWarning: invalid value encountered in double_scalars
      mcc = cov_ytyp / np.sqrt(cov_ytyt * cov_ypyp)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_ridge.py:147: LinAlgWarning: Ill-conditioned matrix (rcond=7.24006e-12): result may not be accurate.
      return linalg.solve(A, Xy, sym_pos=True,
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_ridge.py:147: LinAlgWarning: Ill-conditioned matrix (rcond=9.2358e-12): result may not be accurate.
      return linalg.solve(A, Xy, sym_pos=True,
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/discriminant_analysis.py:715: UserWarning: Variables are collinear
      warnings.warn("Variables are collinear")
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/discriminant_analysis.py:715: UserWarning: Variables are collinear
      warnings.warn("Variables are collinear")



```python
plot_model(gbc_ph, plot='feature')
```


    
![png](output_28_0.png)
    



```python
plot_model(gbc_ph, plot='confusion_matrix')
```


    
![png](output_29_0.png)
    



```python
#we see that hospital gbc is good, pharmacy gbc is weak, but will it help if we combine pharmacy and hospital?
```


```python
ho_df.SUBJ_ID.nunique()
```




    11565




```python
ho_ph = pd.merge(ho_df,ph_df.iloc[:,:-1], how='inner', left_on='SUBJ_ID', right_on = 'SUBJ_ID')
```


```python
ho_ph.shape
```




    (11565, 632)




```python
ho_ph.columns
```




    Index(['SUBJ_ID', '84', '85', '86', '87', '88', '89', '90', '91', '92',
           ...
           '662', '663', '664', '665', '666', '667', '668', '669', '670', '671'],
          dtype='object', length=632)




```python
exp_ho_ph = setup(ho_ph.iloc[:,1:], target = 'label')
```


<style type="text/css">
#T_449fe_row5_col1, #T_449fe_row44_col1 {
  background-color: lightgreen;
}
</style>
<table id="T_449fe_">
  <thead>
    <tr>
      <th class="blank level0" >&nbsp;</th>
      <th class="col_heading level0 col0" >Description</th>
      <th class="col_heading level0 col1" >Value</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th id="T_449fe_level0_row0" class="row_heading level0 row0" >0</th>
      <td id="T_449fe_row0_col0" class="data row0 col0" >session_id</td>
      <td id="T_449fe_row0_col1" class="data row0 col1" >1023</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row1" class="row_heading level0 row1" >1</th>
      <td id="T_449fe_row1_col0" class="data row1 col0" >Target</td>
      <td id="T_449fe_row1_col1" class="data row1 col1" >label</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row2" class="row_heading level0 row2" >2</th>
      <td id="T_449fe_row2_col0" class="data row2 col0" >Target Type</td>
      <td id="T_449fe_row2_col1" class="data row2 col1" >Binary</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row3" class="row_heading level0 row3" >3</th>
      <td id="T_449fe_row3_col0" class="data row3 col0" >Label Encoded</td>
      <td id="T_449fe_row3_col1" class="data row3 col1" >None</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row4" class="row_heading level0 row4" >4</th>
      <td id="T_449fe_row4_col0" class="data row4 col0" >Original Data</td>
      <td id="T_449fe_row4_col1" class="data row4 col1" >(11565, 631)</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row5" class="row_heading level0 row5" >5</th>
      <td id="T_449fe_row5_col0" class="data row5 col0" >Missing Values</td>
      <td id="T_449fe_row5_col1" class="data row5 col1" >True</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row6" class="row_heading level0 row6" >6</th>
      <td id="T_449fe_row6_col0" class="data row6 col0" >Numeric Features</td>
      <td id="T_449fe_row6_col1" class="data row6 col1" >522</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row7" class="row_heading level0 row7" >7</th>
      <td id="T_449fe_row7_col0" class="data row7 col0" >Categorical Features</td>
      <td id="T_449fe_row7_col1" class="data row7 col1" >108</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row8" class="row_heading level0 row8" >8</th>
      <td id="T_449fe_row8_col0" class="data row8 col0" >Ordinal Features</td>
      <td id="T_449fe_row8_col1" class="data row8 col1" >False</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row9" class="row_heading level0 row9" >9</th>
      <td id="T_449fe_row9_col0" class="data row9 col0" >High Cardinality Features</td>
      <td id="T_449fe_row9_col1" class="data row9 col1" >False</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row10" class="row_heading level0 row10" >10</th>
      <td id="T_449fe_row10_col0" class="data row10 col0" >High Cardinality Method</td>
      <td id="T_449fe_row10_col1" class="data row10 col1" >None</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row11" class="row_heading level0 row11" >11</th>
      <td id="T_449fe_row11_col0" class="data row11 col0" >Transformed Train Set</td>
      <td id="T_449fe_row11_col1" class="data row11 col1" >(8095, 1174)</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row12" class="row_heading level0 row12" >12</th>
      <td id="T_449fe_row12_col0" class="data row12 col0" >Transformed Test Set</td>
      <td id="T_449fe_row12_col1" class="data row12 col1" >(3470, 1174)</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row13" class="row_heading level0 row13" >13</th>
      <td id="T_449fe_row13_col0" class="data row13 col0" >Shuffle Train-Test</td>
      <td id="T_449fe_row13_col1" class="data row13 col1" >True</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row14" class="row_heading level0 row14" >14</th>
      <td id="T_449fe_row14_col0" class="data row14 col0" >Stratify Train-Test</td>
      <td id="T_449fe_row14_col1" class="data row14 col1" >False</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row15" class="row_heading level0 row15" >15</th>
      <td id="T_449fe_row15_col0" class="data row15 col0" >Fold Generator</td>
      <td id="T_449fe_row15_col1" class="data row15 col1" >StratifiedKFold</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row16" class="row_heading level0 row16" >16</th>
      <td id="T_449fe_row16_col0" class="data row16 col0" >Fold Number</td>
      <td id="T_449fe_row16_col1" class="data row16 col1" >10</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row17" class="row_heading level0 row17" >17</th>
      <td id="T_449fe_row17_col0" class="data row17 col0" >CPU Jobs</td>
      <td id="T_449fe_row17_col1" class="data row17 col1" >-1</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row18" class="row_heading level0 row18" >18</th>
      <td id="T_449fe_row18_col0" class="data row18 col0" >Use GPU</td>
      <td id="T_449fe_row18_col1" class="data row18 col1" >False</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row19" class="row_heading level0 row19" >19</th>
      <td id="T_449fe_row19_col0" class="data row19 col0" >Log Experiment</td>
      <td id="T_449fe_row19_col1" class="data row19 col1" >False</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row20" class="row_heading level0 row20" >20</th>
      <td id="T_449fe_row20_col0" class="data row20 col0" >Experiment Name</td>
      <td id="T_449fe_row20_col1" class="data row20 col1" >clf-default-name</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row21" class="row_heading level0 row21" >21</th>
      <td id="T_449fe_row21_col0" class="data row21 col0" >USI</td>
      <td id="T_449fe_row21_col1" class="data row21 col1" >7c07</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row22" class="row_heading level0 row22" >22</th>
      <td id="T_449fe_row22_col0" class="data row22 col0" >Imputation Type</td>
      <td id="T_449fe_row22_col1" class="data row22 col1" >simple</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row23" class="row_heading level0 row23" >23</th>
      <td id="T_449fe_row23_col0" class="data row23 col0" >Iterative Imputation Iteration</td>
      <td id="T_449fe_row23_col1" class="data row23 col1" >None</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row24" class="row_heading level0 row24" >24</th>
      <td id="T_449fe_row24_col0" class="data row24 col0" >Numeric Imputer</td>
      <td id="T_449fe_row24_col1" class="data row24 col1" >mean</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row25" class="row_heading level0 row25" >25</th>
      <td id="T_449fe_row25_col0" class="data row25 col0" >Iterative Imputation Numeric Model</td>
      <td id="T_449fe_row25_col1" class="data row25 col1" >None</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row26" class="row_heading level0 row26" >26</th>
      <td id="T_449fe_row26_col0" class="data row26 col0" >Categorical Imputer</td>
      <td id="T_449fe_row26_col1" class="data row26 col1" >constant</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row27" class="row_heading level0 row27" >27</th>
      <td id="T_449fe_row27_col0" class="data row27 col0" >Iterative Imputation Categorical Model</td>
      <td id="T_449fe_row27_col1" class="data row27 col1" >None</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row28" class="row_heading level0 row28" >28</th>
      <td id="T_449fe_row28_col0" class="data row28 col0" >Unknown Categoricals Handling</td>
      <td id="T_449fe_row28_col1" class="data row28 col1" >least_frequent</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row29" class="row_heading level0 row29" >29</th>
      <td id="T_449fe_row29_col0" class="data row29 col0" >Normalize</td>
      <td id="T_449fe_row29_col1" class="data row29 col1" >False</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row30" class="row_heading level0 row30" >30</th>
      <td id="T_449fe_row30_col0" class="data row30 col0" >Normalize Method</td>
      <td id="T_449fe_row30_col1" class="data row30 col1" >None</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row31" class="row_heading level0 row31" >31</th>
      <td id="T_449fe_row31_col0" class="data row31 col0" >Transformation</td>
      <td id="T_449fe_row31_col1" class="data row31 col1" >False</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row32" class="row_heading level0 row32" >32</th>
      <td id="T_449fe_row32_col0" class="data row32 col0" >Transformation Method</td>
      <td id="T_449fe_row32_col1" class="data row32 col1" >None</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row33" class="row_heading level0 row33" >33</th>
      <td id="T_449fe_row33_col0" class="data row33 col0" >PCA</td>
      <td id="T_449fe_row33_col1" class="data row33 col1" >False</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row34" class="row_heading level0 row34" >34</th>
      <td id="T_449fe_row34_col0" class="data row34 col0" >PCA Method</td>
      <td id="T_449fe_row34_col1" class="data row34 col1" >None</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row35" class="row_heading level0 row35" >35</th>
      <td id="T_449fe_row35_col0" class="data row35 col0" >PCA Components</td>
      <td id="T_449fe_row35_col1" class="data row35 col1" >None</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row36" class="row_heading level0 row36" >36</th>
      <td id="T_449fe_row36_col0" class="data row36 col0" >Ignore Low Variance</td>
      <td id="T_449fe_row36_col1" class="data row36 col1" >False</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row37" class="row_heading level0 row37" >37</th>
      <td id="T_449fe_row37_col0" class="data row37 col0" >Combine Rare Levels</td>
      <td id="T_449fe_row37_col1" class="data row37 col1" >False</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row38" class="row_heading level0 row38" >38</th>
      <td id="T_449fe_row38_col0" class="data row38 col0" >Rare Level Threshold</td>
      <td id="T_449fe_row38_col1" class="data row38 col1" >None</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row39" class="row_heading level0 row39" >39</th>
      <td id="T_449fe_row39_col0" class="data row39 col0" >Numeric Binning</td>
      <td id="T_449fe_row39_col1" class="data row39 col1" >False</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row40" class="row_heading level0 row40" >40</th>
      <td id="T_449fe_row40_col0" class="data row40 col0" >Remove Outliers</td>
      <td id="T_449fe_row40_col1" class="data row40 col1" >False</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row41" class="row_heading level0 row41" >41</th>
      <td id="T_449fe_row41_col0" class="data row41 col0" >Outliers Threshold</td>
      <td id="T_449fe_row41_col1" class="data row41 col1" >None</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row42" class="row_heading level0 row42" >42</th>
      <td id="T_449fe_row42_col0" class="data row42 col0" >Remove Multicollinearity</td>
      <td id="T_449fe_row42_col1" class="data row42 col1" >False</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row43" class="row_heading level0 row43" >43</th>
      <td id="T_449fe_row43_col0" class="data row43 col0" >Multicollinearity Threshold</td>
      <td id="T_449fe_row43_col1" class="data row43 col1" >None</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row44" class="row_heading level0 row44" >44</th>
      <td id="T_449fe_row44_col0" class="data row44 col0" >Remove Perfect Collinearity</td>
      <td id="T_449fe_row44_col1" class="data row44 col1" >True</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row45" class="row_heading level0 row45" >45</th>
      <td id="T_449fe_row45_col0" class="data row45 col0" >Clustering</td>
      <td id="T_449fe_row45_col1" class="data row45 col1" >False</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row46" class="row_heading level0 row46" >46</th>
      <td id="T_449fe_row46_col0" class="data row46 col0" >Clustering Iteration</td>
      <td id="T_449fe_row46_col1" class="data row46 col1" >None</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row47" class="row_heading level0 row47" >47</th>
      <td id="T_449fe_row47_col0" class="data row47 col0" >Polynomial Features</td>
      <td id="T_449fe_row47_col1" class="data row47 col1" >False</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row48" class="row_heading level0 row48" >48</th>
      <td id="T_449fe_row48_col0" class="data row48 col0" >Polynomial Degree</td>
      <td id="T_449fe_row48_col1" class="data row48 col1" >None</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row49" class="row_heading level0 row49" >49</th>
      <td id="T_449fe_row49_col0" class="data row49 col0" >Trignometry Features</td>
      <td id="T_449fe_row49_col1" class="data row49 col1" >False</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row50" class="row_heading level0 row50" >50</th>
      <td id="T_449fe_row50_col0" class="data row50 col0" >Polynomial Threshold</td>
      <td id="T_449fe_row50_col1" class="data row50 col1" >None</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row51" class="row_heading level0 row51" >51</th>
      <td id="T_449fe_row51_col0" class="data row51 col0" >Group Features</td>
      <td id="T_449fe_row51_col1" class="data row51 col1" >False</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row52" class="row_heading level0 row52" >52</th>
      <td id="T_449fe_row52_col0" class="data row52 col0" >Feature Selection</td>
      <td id="T_449fe_row52_col1" class="data row52 col1" >False</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row53" class="row_heading level0 row53" >53</th>
      <td id="T_449fe_row53_col0" class="data row53 col0" >Feature Selection Method</td>
      <td id="T_449fe_row53_col1" class="data row53 col1" >classic</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row54" class="row_heading level0 row54" >54</th>
      <td id="T_449fe_row54_col0" class="data row54 col0" >Features Selection Threshold</td>
      <td id="T_449fe_row54_col1" class="data row54 col1" >None</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row55" class="row_heading level0 row55" >55</th>
      <td id="T_449fe_row55_col0" class="data row55 col0" >Feature Interaction</td>
      <td id="T_449fe_row55_col1" class="data row55 col1" >False</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row56" class="row_heading level0 row56" >56</th>
      <td id="T_449fe_row56_col0" class="data row56 col0" >Feature Ratio</td>
      <td id="T_449fe_row56_col1" class="data row56 col1" >False</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row57" class="row_heading level0 row57" >57</th>
      <td id="T_449fe_row57_col0" class="data row57 col0" >Interaction Threshold</td>
      <td id="T_449fe_row57_col1" class="data row57 col1" >None</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row58" class="row_heading level0 row58" >58</th>
      <td id="T_449fe_row58_col0" class="data row58 col0" >Fix Imbalance</td>
      <td id="T_449fe_row58_col1" class="data row58 col1" >False</td>
    </tr>
    <tr>
      <th id="T_449fe_level0_row59" class="row_heading level0 row59" >59</th>
      <td id="T_449fe_row59_col0" class="data row59 col0" >Fix Imbalance Method</td>
      <td id="T_449fe_row59_col1" class="data row59 col1" >SMOTE</td>
    </tr>
  </tbody>
</table>




```python
compare_models()
```


<style type="text/css">
#T_0e06b_ th {
  text-align: left;
}
#T_0e06b_row0_col0, #T_0e06b_row0_col2, #T_0e06b_row0_col3, #T_0e06b_row0_col4, #T_0e06b_row0_col5, #T_0e06b_row0_col6, #T_0e06b_row1_col0, #T_0e06b_row1_col1, #T_0e06b_row1_col2, #T_0e06b_row1_col3, #T_0e06b_row1_col5, #T_0e06b_row1_col6, #T_0e06b_row1_col7, #T_0e06b_row2_col0, #T_0e06b_row2_col1, #T_0e06b_row2_col3, #T_0e06b_row2_col4, #T_0e06b_row2_col5, #T_0e06b_row2_col6, #T_0e06b_row2_col7, #T_0e06b_row3_col0, #T_0e06b_row3_col1, #T_0e06b_row3_col2, #T_0e06b_row3_col3, #T_0e06b_row3_col4, #T_0e06b_row3_col5, #T_0e06b_row3_col6, #T_0e06b_row3_col7, #T_0e06b_row4_col0, #T_0e06b_row4_col1, #T_0e06b_row4_col2, #T_0e06b_row4_col3, #T_0e06b_row4_col4, #T_0e06b_row4_col5, #T_0e06b_row4_col7, #T_0e06b_row5_col0, #T_0e06b_row5_col1, #T_0e06b_row5_col2, #T_0e06b_row5_col3, #T_0e06b_row5_col4, #T_0e06b_row5_col5, #T_0e06b_row5_col6, #T_0e06b_row5_col7, #T_0e06b_row6_col0, #T_0e06b_row6_col1, #T_0e06b_row6_col2, #T_0e06b_row6_col3, #T_0e06b_row6_col4, #T_0e06b_row6_col5, #T_0e06b_row6_col6, #T_0e06b_row6_col7, #T_0e06b_row7_col0, #T_0e06b_row7_col1, #T_0e06b_row7_col2, #T_0e06b_row7_col3, #T_0e06b_row7_col4, #T_0e06b_row7_col5, #T_0e06b_row7_col6, #T_0e06b_row7_col7, #T_0e06b_row8_col0, #T_0e06b_row8_col1, #T_0e06b_row8_col2, #T_0e06b_row8_col3, #T_0e06b_row8_col4, #T_0e06b_row8_col5, #T_0e06b_row8_col6, #T_0e06b_row8_col7, #T_0e06b_row9_col0, #T_0e06b_row9_col1, #T_0e06b_row9_col2, #T_0e06b_row9_col3, #T_0e06b_row9_col4, #T_0e06b_row9_col5, #T_0e06b_row9_col6, #T_0e06b_row9_col7, #T_0e06b_row10_col0, #T_0e06b_row10_col1, #T_0e06b_row10_col2, #T_0e06b_row10_col3, #T_0e06b_row10_col4, #T_0e06b_row10_col6, #T_0e06b_row10_col7, #T_0e06b_row11_col0, #T_0e06b_row11_col1, #T_0e06b_row11_col2, #T_0e06b_row11_col3, #T_0e06b_row11_col4, #T_0e06b_row11_col5, #T_0e06b_row11_col6, #T_0e06b_row11_col7, #T_0e06b_row12_col0, #T_0e06b_row12_col1, #T_0e06b_row12_col2, #T_0e06b_row12_col4, #T_0e06b_row12_col5, #T_0e06b_row12_col6, #T_0e06b_row12_col7 {
  text-align: left;
}
#T_0e06b_row0_col1, #T_0e06b_row0_col7, #T_0e06b_row1_col4, #T_0e06b_row2_col2, #T_0e06b_row4_col6, #T_0e06b_row10_col5, #T_0e06b_row12_col3 {
  text-align: left;
  background-color: yellow;
}
#T_0e06b_row0_col8, #T_0e06b_row1_col8, #T_0e06b_row2_col8, #T_0e06b_row3_col8, #T_0e06b_row4_col8, #T_0e06b_row5_col8, #T_0e06b_row6_col8, #T_0e06b_row7_col8, #T_0e06b_row8_col8, #T_0e06b_row9_col8, #T_0e06b_row11_col8, #T_0e06b_row12_col8 {
  text-align: left;
  background-color: lightgrey;
}
#T_0e06b_row10_col8 {
  text-align: left;
  background-color: yellow;
  background-color: lightgrey;
}
</style>
<table id="T_0e06b_">
  <thead>
    <tr>
      <th class="blank level0" >&nbsp;</th>
      <th class="col_heading level0 col0" >Model</th>
      <th class="col_heading level0 col1" >Accuracy</th>
      <th class="col_heading level0 col2" >AUC</th>
      <th class="col_heading level0 col3" >Recall</th>
      <th class="col_heading level0 col4" >Prec.</th>
      <th class="col_heading level0 col5" >F1</th>
      <th class="col_heading level0 col6" >Kappa</th>
      <th class="col_heading level0 col7" >MCC</th>
      <th class="col_heading level0 col8" >TT (Sec)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th id="T_0e06b_level0_row0" class="row_heading level0 row0" >gbc</th>
      <td id="T_0e06b_row0_col0" class="data row0 col0" >Gradient Boosting Classifier</td>
      <td id="T_0e06b_row0_col1" class="data row0 col1" >0.8871</td>
      <td id="T_0e06b_row0_col2" class="data row0 col2" >0.8610</td>
      <td id="T_0e06b_row0_col3" class="data row0 col3" >0.3028</td>
      <td id="T_0e06b_row0_col4" class="data row0 col4" >0.6490</td>
      <td id="T_0e06b_row0_col5" class="data row0 col5" >0.4124</td>
      <td id="T_0e06b_row0_col6" class="data row0 col6" >0.3590</td>
      <td id="T_0e06b_row0_col7" class="data row0 col7" >0.3913</td>
      <td id="T_0e06b_row0_col8" class="data row0 col8" >24.8230</td>
    </tr>
    <tr>
      <th id="T_0e06b_level0_row1" class="row_heading level0 row1" >rf</th>
      <td id="T_0e06b_row1_col0" class="data row1 col0" >Random Forest Classifier</td>
      <td id="T_0e06b_row1_col1" class="data row1 col1" >0.8868</td>
      <td id="T_0e06b_row1_col2" class="data row1 col2" >0.8505</td>
      <td id="T_0e06b_row1_col3" class="data row1 col3" >0.2340</td>
      <td id="T_0e06b_row1_col4" class="data row1 col4" >0.7086</td>
      <td id="T_0e06b_row1_col5" class="data row1 col5" >0.3499</td>
      <td id="T_0e06b_row1_col6" class="data row1 col6" >0.3050</td>
      <td id="T_0e06b_row1_col7" class="data row1 col7" >0.3625</td>
      <td id="T_0e06b_row1_col8" class="data row1 col8" >3.0970</td>
    </tr>
    <tr>
      <th id="T_0e06b_level0_row2" class="row_heading level0 row2" >lightgbm</th>
      <td id="T_0e06b_row2_col0" class="data row2 col0" >Light Gradient Boosting Machine</td>
      <td id="T_0e06b_row2_col1" class="data row2 col1" >0.8854</td>
      <td id="T_0e06b_row2_col2" class="data row2 col2" >0.8636</td>
      <td id="T_0e06b_row2_col3" class="data row2 col3" >0.3019</td>
      <td id="T_0e06b_row2_col4" class="data row2 col4" >0.6340</td>
      <td id="T_0e06b_row2_col5" class="data row2 col5" >0.4079</td>
      <td id="T_0e06b_row2_col6" class="data row2 col6" >0.3532</td>
      <td id="T_0e06b_row2_col7" class="data row2 col7" >0.3837</td>
      <td id="T_0e06b_row2_col8" class="data row2 col8" >3.0800</td>
    </tr>
    <tr>
      <th id="T_0e06b_level0_row3" class="row_heading level0 row3" >et</th>
      <td id="T_0e06b_row3_col0" class="data row3 col0" >Extra Trees Classifier</td>
      <td id="T_0e06b_row3_col1" class="data row3 col1" >0.8840</td>
      <td id="T_0e06b_row3_col2" class="data row3 col2" >0.8478</td>
      <td id="T_0e06b_row3_col3" class="data row3 col3" >0.2189</td>
      <td id="T_0e06b_row3_col4" class="data row3 col4" >0.6799</td>
      <td id="T_0e06b_row3_col5" class="data row3 col5" >0.3298</td>
      <td id="T_0e06b_row3_col6" class="data row3 col6" >0.2843</td>
      <td id="T_0e06b_row3_col7" class="data row3 col7" >0.3403</td>
      <td id="T_0e06b_row3_col8" class="data row3 col8" >1.6780</td>
    </tr>
    <tr>
      <th id="T_0e06b_level0_row4" class="row_heading level0 row4" >ada</th>
      <td id="T_0e06b_row4_col0" class="data row4 col0" >Ada Boost Classifier</td>
      <td id="T_0e06b_row4_col1" class="data row4 col1" >0.8803</td>
      <td id="T_0e06b_row4_col2" class="data row4 col2" >0.8485</td>
      <td id="T_0e06b_row4_col3" class="data row4 col3" >0.3368</td>
      <td id="T_0e06b_row4_col4" class="data row4 col4" >0.5756</td>
      <td id="T_0e06b_row4_col5" class="data row4 col5" >0.4236</td>
      <td id="T_0e06b_row4_col6" class="data row4 col6" >0.3620</td>
      <td id="T_0e06b_row4_col7" class="data row4 col7" >0.3789</td>
      <td id="T_0e06b_row4_col8" class="data row4 col8" >4.9240</td>
    </tr>
    <tr>
      <th id="T_0e06b_level0_row5" class="row_heading level0 row5" >ridge</th>
      <td id="T_0e06b_row5_col0" class="data row5 col0" >Ridge Classifier</td>
      <td id="T_0e06b_row5_col1" class="data row5 col1" >0.8792</td>
      <td id="T_0e06b_row5_col2" class="data row5 col2" >0.0000</td>
      <td id="T_0e06b_row5_col3" class="data row5 col3" >0.2887</td>
      <td id="T_0e06b_row5_col4" class="data row5 col4" >0.5798</td>
      <td id="T_0e06b_row5_col5" class="data row5 col5" >0.3839</td>
      <td id="T_0e06b_row5_col6" class="data row5 col6" >0.3254</td>
      <td id="T_0e06b_row5_col7" class="data row5 col7" >0.3505</td>
      <td id="T_0e06b_row5_col8" class="data row5 col8" >0.2200</td>
    </tr>
    <tr>
      <th id="T_0e06b_level0_row6" class="row_heading level0 row6" >lr</th>
      <td id="T_0e06b_row6_col0" class="data row6 col0" >Logistic Regression</td>
      <td id="T_0e06b_row6_col1" class="data row6 col1" >0.8781</td>
      <td id="T_0e06b_row6_col2" class="data row6 col2" >0.8282</td>
      <td id="T_0e06b_row6_col3" class="data row6 col3" >0.3104</td>
      <td id="T_0e06b_row6_col4" class="data row6 col4" >0.5637</td>
      <td id="T_0e06b_row6_col5" class="data row6 col5" >0.3988</td>
      <td id="T_0e06b_row6_col6" class="data row6 col6" >0.3375</td>
      <td id="T_0e06b_row6_col7" class="data row6 col7" >0.3568</td>
      <td id="T_0e06b_row6_col8" class="data row6 col8" >8.1960</td>
    </tr>
    <tr>
      <th id="T_0e06b_level0_row7" class="row_heading level0 row7" >lda</th>
      <td id="T_0e06b_row7_col0" class="data row7 col0" >Linear Discriminant Analysis</td>
      <td id="T_0e06b_row7_col1" class="data row7 col1" >0.8644</td>
      <td id="T_0e06b_row7_col2" class="data row7 col2" >0.7870</td>
      <td id="T_0e06b_row7_col3" class="data row7 col3" >0.3783</td>
      <td id="T_0e06b_row7_col4" class="data row7 col4" >0.4789</td>
      <td id="T_0e06b_row7_col5" class="data row7 col5" >0.4219</td>
      <td id="T_0e06b_row7_col6" class="data row7 col6" >0.3464</td>
      <td id="T_0e06b_row7_col7" class="data row7 col7" >0.3499</td>
      <td id="T_0e06b_row7_col8" class="data row7 col8" >2.3520</td>
    </tr>
    <tr>
      <th id="T_0e06b_level0_row8" class="row_heading level0 row8" >knn</th>
      <td id="T_0e06b_row8_col0" class="data row8 col0" >K Neighbors Classifier</td>
      <td id="T_0e06b_row8_col1" class="data row8 col1" >0.8621</td>
      <td id="T_0e06b_row8_col2" class="data row8 col2" >0.6011</td>
      <td id="T_0e06b_row8_col3" class="data row8 col3" >0.0274</td>
      <td id="T_0e06b_row8_col4" class="data row8 col4" >0.2540</td>
      <td id="T_0e06b_row8_col5" class="data row8 col5" >0.0490</td>
      <td id="T_0e06b_row8_col6" class="data row8 col6" >0.0244</td>
      <td id="T_0e06b_row8_col7" class="data row8 col7" >0.0431</td>
      <td id="T_0e06b_row8_col8" class="data row8 col8" >9.3290</td>
    </tr>
    <tr>
      <th id="T_0e06b_level0_row9" class="row_heading level0 row9" >dt</th>
      <td id="T_0e06b_row9_col0" class="data row9 col0" >Decision Tree Classifier</td>
      <td id="T_0e06b_row9_col1" class="data row9 col1" >0.8215</td>
      <td id="T_0e06b_row9_col2" class="data row9 col2" >0.6209</td>
      <td id="T_0e06b_row9_col3" class="data row9 col3" >0.3491</td>
      <td id="T_0e06b_row9_col4" class="data row9 col4" >0.3309</td>
      <td id="T_0e06b_row9_col5" class="data row9 col5" >0.3394</td>
      <td id="T_0e06b_row9_col6" class="data row9 col6" >0.2364</td>
      <td id="T_0e06b_row9_col7" class="data row9 col7" >0.2367</td>
      <td id="T_0e06b_row9_col8" class="data row9 col8" >2.1540</td>
    </tr>
    <tr>
      <th id="T_0e06b_level0_row10" class="row_heading level0 row10" >nb</th>
      <td id="T_0e06b_row10_col0" class="data row10 col0" >Naive Bayes</td>
      <td id="T_0e06b_row10_col1" class="data row10 col1" >0.8102</td>
      <td id="T_0e06b_row10_col2" class="data row10 col2" >0.7677</td>
      <td id="T_0e06b_row10_col3" class="data row10 col3" >0.5538</td>
      <td id="T_0e06b_row10_col4" class="data row10 col4" >0.3577</td>
      <td id="T_0e06b_row10_col5" class="data row10 col5" >0.4340</td>
      <td id="T_0e06b_row10_col6" class="data row10 col6" >0.3267</td>
      <td id="T_0e06b_row10_col7" class="data row10 col7" >0.3382</td>
      <td id="T_0e06b_row10_col8" class="data row10 col8" >0.1040</td>
    </tr>
    <tr>
      <th id="T_0e06b_level0_row11" class="row_heading level0 row11" >svm</th>
      <td id="T_0e06b_row11_col0" class="data row11 col0" >SVM - Linear Kernel</td>
      <td id="T_0e06b_row11_col1" class="data row11 col1" >0.8101</td>
      <td id="T_0e06b_row11_col2" class="data row11 col2" >0.0000</td>
      <td id="T_0e06b_row11_col3" class="data row11 col3" >0.2160</td>
      <td id="T_0e06b_row11_col4" class="data row11 col4" >0.2746</td>
      <td id="T_0e06b_row11_col5" class="data row11 col5" >0.2135</td>
      <td id="T_0e06b_row11_col6" class="data row11 col6" >0.1189</td>
      <td id="T_0e06b_row11_col7" class="data row11 col7" >0.1302</td>
      <td id="T_0e06b_row11_col8" class="data row11 col8" >0.1780</td>
    </tr>
    <tr>
      <th id="T_0e06b_level0_row12" class="row_heading level0 row12" >qda</th>
      <td id="T_0e06b_row12_col0" class="data row12 col0" >Quadratic Discriminant Analysis</td>
      <td id="T_0e06b_row12_col1" class="data row12 col1" >0.1309</td>
      <td id="T_0e06b_row12_col2" class="data row12 col2" >0.5000</td>
      <td id="T_0e06b_row12_col3" class="data row12 col3" >1.0000</td>
      <td id="T_0e06b_row12_col4" class="data row12 col4" >0.1309</td>
      <td id="T_0e06b_row12_col5" class="data row12 col5" >0.2316</td>
      <td id="T_0e06b_row12_col6" class="data row12 col6" >0.0000</td>
      <td id="T_0e06b_row12_col7" class="data row12 col7" >0.0000</td>
      <td id="T_0e06b_row12_col8" class="data row12 col8" >2.8170</td>
    </tr>
  </tbody>
</table>






    GradientBoostingClassifier(ccp_alpha=0.0, criterion='friedman_mse', init=None,
                               learning_rate=0.1, loss='deviance', max_depth=3,
                               max_features=None, max_leaf_nodes=None,
                               min_impurity_decrease=0.0, min_impurity_split=None,
                               min_samples_leaf=1, min_samples_split=2,
                               min_weight_fraction_leaf=0.0, n_estimators=100,
                               n_iter_no_change=None, presort='deprecated',
                               random_state=1023, subsample=1.0, tol=0.0001,
                               validation_fraction=0.1, verbose=0,
                               warm_start=False)




```python
ho_ph_gbc = create_model('gbc')
```


<style type="text/css">
#T_2edfd_row10_col0, #T_2edfd_row10_col1, #T_2edfd_row10_col2, #T_2edfd_row10_col3, #T_2edfd_row10_col4, #T_2edfd_row10_col5, #T_2edfd_row10_col6 {
  background: yellow;
}
</style>
<table id="T_2edfd_">
  <thead>
    <tr>
      <th class="blank level0" >&nbsp;</th>
      <th class="col_heading level0 col0" >Accuracy</th>
      <th class="col_heading level0 col1" >AUC</th>
      <th class="col_heading level0 col2" >Recall</th>
      <th class="col_heading level0 col3" >Prec.</th>
      <th class="col_heading level0 col4" >F1</th>
      <th class="col_heading level0 col5" >Kappa</th>
      <th class="col_heading level0 col6" >MCC</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th id="T_2edfd_level0_row0" class="row_heading level0 row0" >0</th>
      <td id="T_2edfd_row0_col0" class="data row0 col0" >0.8802</td>
      <td id="T_2edfd_row0_col1" class="data row0 col1" >0.8831</td>
      <td id="T_2edfd_row0_col2" class="data row0 col2" >0.2925</td>
      <td id="T_2edfd_row0_col3" class="data row0 col3" >0.5849</td>
      <td id="T_2edfd_row0_col4" class="data row0 col4" >0.3899</td>
      <td id="T_2edfd_row0_col5" class="data row0 col5" >0.3316</td>
      <td id="T_2edfd_row0_col6" class="data row0 col6" >0.3562</td>
    </tr>
    <tr>
      <th id="T_2edfd_level0_row1" class="row_heading level0 row1" >1</th>
      <td id="T_2edfd_row1_col0" class="data row1 col0" >0.8901</td>
      <td id="T_2edfd_row1_col1" class="data row1 col1" >0.9035</td>
      <td id="T_2edfd_row1_col2" class="data row1 col2" >0.2925</td>
      <td id="T_2edfd_row1_col3" class="data row1 col3" >0.6889</td>
      <td id="T_2edfd_row1_col4" class="data row1 col4" >0.4106</td>
      <td id="T_2edfd_row1_col5" class="data row1 col5" >0.3607</td>
      <td id="T_2edfd_row1_col6" class="data row1 col6" >0.4013</td>
    </tr>
    <tr>
      <th id="T_2edfd_level0_row2" class="row_heading level0 row2" >2</th>
      <td id="T_2edfd_row2_col0" class="data row2 col0" >0.8877</td>
      <td id="T_2edfd_row2_col1" class="data row2 col1" >0.8565</td>
      <td id="T_2edfd_row2_col2" class="data row2 col2" >0.3019</td>
      <td id="T_2edfd_row2_col3" class="data row2 col3" >0.6531</td>
      <td id="T_2edfd_row2_col4" class="data row2 col4" >0.4129</td>
      <td id="T_2edfd_row2_col5" class="data row2 col5" >0.3599</td>
      <td id="T_2edfd_row2_col6" class="data row2 col6" >0.3929</td>
    </tr>
    <tr>
      <th id="T_2edfd_level0_row3" class="row_heading level0 row3" >3</th>
      <td id="T_2edfd_row3_col0" class="data row3 col0" >0.8901</td>
      <td id="T_2edfd_row3_col1" class="data row3 col1" >0.8633</td>
      <td id="T_2edfd_row3_col2" class="data row3 col2" >0.3208</td>
      <td id="T_2edfd_row3_col3" class="data row3 col3" >0.6667</td>
      <td id="T_2edfd_row3_col4" class="data row3 col4" >0.4331</td>
      <td id="T_2edfd_row3_col5" class="data row3 col5" >0.3804</td>
      <td id="T_2edfd_row3_col6" class="data row3 col6" >0.4118</td>
    </tr>
    <tr>
      <th id="T_2edfd_level0_row4" class="row_heading level0 row4" >4</th>
      <td id="T_2edfd_row4_col0" class="data row4 col0" >0.8889</td>
      <td id="T_2edfd_row4_col1" class="data row4 col1" >0.8460</td>
      <td id="T_2edfd_row4_col2" class="data row4 col2" >0.2830</td>
      <td id="T_2edfd_row4_col3" class="data row4 col3" >0.6818</td>
      <td id="T_2edfd_row4_col4" class="data row4 col4" >0.4000</td>
      <td id="T_2edfd_row4_col5" class="data row4 col5" >0.3501</td>
      <td id="T_2edfd_row4_col6" class="data row4 col6" >0.3915</td>
    </tr>
    <tr>
      <th id="T_2edfd_level0_row5" class="row_heading level0 row5" >5</th>
      <td id="T_2edfd_row5_col0" class="data row5 col0" >0.8912</td>
      <td id="T_2edfd_row5_col1" class="data row5 col1" >0.8646</td>
      <td id="T_2edfd_row5_col2" class="data row5 col2" >0.3019</td>
      <td id="T_2edfd_row5_col3" class="data row5 col3" >0.6957</td>
      <td id="T_2edfd_row5_col4" class="data row5 col4" >0.4211</td>
      <td id="T_2edfd_row5_col5" class="data row5 col5" >0.3712</td>
      <td id="T_2edfd_row5_col6" class="data row5 col6" >0.4109</td>
    </tr>
    <tr>
      <th id="T_2edfd_level0_row6" class="row_heading level0 row6" >6</th>
      <td id="T_2edfd_row6_col0" class="data row6 col0" >0.8863</td>
      <td id="T_2edfd_row6_col1" class="data row6 col1" >0.8432</td>
      <td id="T_2edfd_row6_col2" class="data row6 col2" >0.3208</td>
      <td id="T_2edfd_row6_col3" class="data row6 col3" >0.6296</td>
      <td id="T_2edfd_row6_col4" class="data row6 col4" >0.4250</td>
      <td id="T_2edfd_row6_col5" class="data row6 col5" >0.3692</td>
      <td id="T_2edfd_row6_col6" class="data row6 col6" >0.3952</td>
    </tr>
    <tr>
      <th id="T_2edfd_level0_row7" class="row_heading level0 row7" >7</th>
      <td id="T_2edfd_row7_col0" class="data row7 col0" >0.8714</td>
      <td id="T_2edfd_row7_col1" class="data row7 col1" >0.8262</td>
      <td id="T_2edfd_row7_col2" class="data row7 col2" >0.2453</td>
      <td id="T_2edfd_row7_col3" class="data row7 col3" >0.5200</td>
      <td id="T_2edfd_row7_col4" class="data row7 col4" >0.3333</td>
      <td id="T_2edfd_row7_col5" class="data row7 col5" >0.2722</td>
      <td id="T_2edfd_row7_col6" class="data row7 col6" >0.2959</td>
    </tr>
    <tr>
      <th id="T_2edfd_level0_row8" class="row_heading level0 row8" >8</th>
      <td id="T_2edfd_row8_col0" class="data row8 col0" >0.8937</td>
      <td id="T_2edfd_row8_col1" class="data row8 col1" >0.8581</td>
      <td id="T_2edfd_row8_col2" class="data row8 col2" >0.3208</td>
      <td id="T_2edfd_row8_col3" class="data row8 col3" >0.7083</td>
      <td id="T_2edfd_row8_col4" class="data row8 col4" >0.4416</td>
      <td id="T_2edfd_row8_col5" class="data row8 col5" >0.3919</td>
      <td id="T_2edfd_row8_col6" class="data row8 col6" >0.4297</td>
    </tr>
    <tr>
      <th id="T_2edfd_level0_row9" class="row_heading level0 row9" >9</th>
      <td id="T_2edfd_row9_col0" class="data row9 col0" >0.8912</td>
      <td id="T_2edfd_row9_col1" class="data row9 col1" >0.8657</td>
      <td id="T_2edfd_row9_col2" class="data row9 col2" >0.3491</td>
      <td id="T_2edfd_row9_col3" class="data row9 col3" >0.6607</td>
      <td id="T_2edfd_row9_col4" class="data row9 col4" >0.4568</td>
      <td id="T_2edfd_row9_col5" class="data row9 col5" >0.4027</td>
      <td id="T_2edfd_row9_col6" class="data row9 col6" >0.4281</td>
    </tr>
    <tr>
      <th id="T_2edfd_level0_row10" class="row_heading level0 row10" >Mean</th>
      <td id="T_2edfd_row10_col0" class="data row10 col0" >0.8871</td>
      <td id="T_2edfd_row10_col1" class="data row10 col1" >0.8610</td>
      <td id="T_2edfd_row10_col2" class="data row10 col2" >0.3028</td>
      <td id="T_2edfd_row10_col3" class="data row10 col3" >0.6490</td>
      <td id="T_2edfd_row10_col4" class="data row10 col4" >0.4124</td>
      <td id="T_2edfd_row10_col5" class="data row10 col5" >0.3590</td>
      <td id="T_2edfd_row10_col6" class="data row10 col6" >0.3913</td>
    </tr>
    <tr>
      <th id="T_2edfd_level0_row11" class="row_heading level0 row11" >SD</th>
      <td id="T_2edfd_row11_col0" class="data row11 col0" >0.0063</td>
      <td id="T_2edfd_row11_col1" class="data row11 col1" >0.0203</td>
      <td id="T_2edfd_row11_col2" class="data row11 col2" >0.0265</td>
      <td id="T_2edfd_row11_col3" class="data row11 col3" >0.0547</td>
      <td id="T_2edfd_row11_col4" class="data row11 col4" >0.0322</td>
      <td id="T_2edfd_row11_col5" class="data row11 col5" >0.0347</td>
      <td id="T_2edfd_row11_col6" class="data row11 col6" >0.0375</td>
    </tr>
  </tbody>
</table>




```python
plot_model(ho_ph_gbc, plot='feature')
```


    
![png](output_38_0.png)
    



```python
plot_model(ho_ph_gbc, plot='confusion_matrix')
```


    
![png](output_39_0.png)
    


    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_logistic.py:762: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_logistic.py:762: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_logistic.py:762: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_ridge.py:147: LinAlgWarning: Ill-conditioned matrix (rcond=7.57928e-12): result may not be accurate.
      return linalg.solve(A, Xy, sym_pos=True,
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_ridge.py:147: LinAlgWarning: Ill-conditioned matrix (rcond=9.54152e-12): result may not be accurate.
      return linalg.solve(A, Xy, sym_pos=True,
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/discriminant_analysis.py:715: UserWarning: Variables are collinear
      warnings.warn("Variables are collinear")
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/metrics/_classification.py:846: RuntimeWarning: invalid value encountered in double_scalars
      mcc = cov_ytyp / np.sqrt(cov_ytyt * cov_ypyp)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/discriminant_analysis.py:715: UserWarning: Variables are collinear
      warnings.warn("Variables are collinear")
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/metrics/_classification.py:846: RuntimeWarning: invalid value encountered in double_scalars
      mcc = cov_ytyp / np.sqrt(cov_ytyt * cov_ypyp)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_logistic.py:762: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_logistic.py:762: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_ridge.py:147: LinAlgWarning: Ill-conditioned matrix (rcond=7.68632e-12): result may not be accurate.
      return linalg.solve(A, Xy, sym_pos=True,
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_ridge.py:147: LinAlgWarning: Ill-conditioned matrix (rcond=7.94241e-12): result may not be accurate.
      return linalg.solve(A, Xy, sym_pos=True,
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_ridge.py:147: LinAlgWarning: Ill-conditioned matrix (rcond=6.09156e-12): result may not be accurate.
      return linalg.solve(A, Xy, sym_pos=True,
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/discriminant_analysis.py:715: UserWarning: Variables are collinear
      warnings.warn("Variables are collinear")
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/metrics/_classification.py:846: RuntimeWarning: invalid value encountered in double_scalars
      mcc = cov_ytyp / np.sqrt(cov_ytyt * cov_ypyp)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/discriminant_analysis.py:715: UserWarning: Variables are collinear
      warnings.warn("Variables are collinear")
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/metrics/_classification.py:846: RuntimeWarning: invalid value encountered in double_scalars
      mcc = cov_ytyp / np.sqrt(cov_ytyt * cov_ypyp)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/discriminant_analysis.py:715: UserWarning: Variables are collinear
      warnings.warn("Variables are collinear")
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/metrics/_classification.py:846: RuntimeWarning: invalid value encountered in double_scalars
      mcc = cov_ytyp / np.sqrt(cov_ytyt * cov_ypyp)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_logistic.py:762: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_logistic.py:762: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_logistic.py:762: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_ridge.py:147: LinAlgWarning: Ill-conditioned matrix (rcond=9.08118e-12): result may not be accurate.
      return linalg.solve(A, Xy, sym_pos=True,
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_ridge.py:147: LinAlgWarning: Ill-conditioned matrix (rcond=1.9071e-11): result may not be accurate.
      return linalg.solve(A, Xy, sym_pos=True,
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/discriminant_analysis.py:715: UserWarning: Variables are collinear
      warnings.warn("Variables are collinear")
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/metrics/_classification.py:846: RuntimeWarning: invalid value encountered in double_scalars
      mcc = cov_ytyp / np.sqrt(cov_ytyt * cov_ypyp)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/discriminant_analysis.py:715: UserWarning: Variables are collinear
      warnings.warn("Variables are collinear")
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/metrics/_classification.py:846: RuntimeWarning: invalid value encountered in double_scalars
      mcc = cov_ytyp / np.sqrt(cov_ytyt * cov_ypyp)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/discriminant_analysis.py:715: UserWarning: Variables are collinear
      warnings.warn("Variables are collinear")
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/metrics/_classification.py:846: RuntimeWarning: invalid value encountered in double_scalars
      mcc = cov_ytyp / np.sqrt(cov_ytyt * cov_ypyp)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_logistic.py:762: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_logistic.py:762: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute standard_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_coef_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/utils/deprecation.py:101: FutureWarning: Attribute average_intercept_ was deprecated in version 0.23 and will be removed in 0.25.
      warnings.warn(msg, category=FutureWarning)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_ridge.py:147: LinAlgWarning: Ill-conditioned matrix (rcond=7.73918e-12): result may not be accurate.
      return linalg.solve(A, Xy, sym_pos=True,
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_ridge.py:147: LinAlgWarning: Ill-conditioned matrix (rcond=7.58294e-12): result may not be accurate.
      return linalg.solve(A, Xy, sym_pos=True,
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/linear_model/_ridge.py:147: LinAlgWarning: Ill-conditioned matrix (rcond=7.58967e-12): result may not be accurate.
      return linalg.solve(A, Xy, sym_pos=True,
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/discriminant_analysis.py:715: UserWarning: Variables are collinear
      warnings.warn("Variables are collinear")
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/metrics/_classification.py:846: RuntimeWarning: invalid value encountered in double_scalars
      mcc = cov_ytyp / np.sqrt(cov_ytyt * cov_ypyp)
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/discriminant_analysis.py:715: UserWarning: Variables are collinear
      warnings.warn("Variables are collinear")
    /ssd003/projects/aieng/public/loblaws_env/lib/python3.8/site-packages/sklearn/metrics/_classification.py:846: RuntimeWarning: invalid value encountered in double_scalars
      mcc = cov_ytyp / np.sqrt(cov_ytyt * cov_ypyp)


#for predicting hospital mortality there is little value in the suggested split, but in other cases it may have more value


```python

```
